# BreatheSafe Schools

A Delhi-NCR school air-safety decision-support prototype with a high-contrast, responsive command center and AQI-responsive Three.js campus. The 3D airfield animates airflow, particulate, a safety boundary and a school sensor; activity rules show explainable GO / MODIFY / NO-GO calls for PE, assemblies, sports and competitions.

## Run locally

```sh
pnpm install
pnpm dev
```

The Express server serves the React/Vite Preview and the same-origin `/api/tinyfish/*` relay on port 3000. Run `pnpm build` to compile the TypeScript app into `dist/`; `pnpm test` runs the offline CPCB/CAQM parser tests. `pnpm start` runs the production server. The included Dockerfile provides the container shape.

## TinyFish Search + Fetch integration

`server/tinyfish.mjs` calls TinyFish Search and Fetch only. The browser calls `POST /api/tinyfish/refresh`; the API key is read solely by the server from protected project runtime configuration as `TINYFISH_API_KEY`. Do not put it in client code, a committed `.env`, or a Vite-prefixed variable. Government domains are allow-listed, request sizes and refresh cadence are bounded, results are cached briefly, and source URLs, retrieval times, warnings and provider errors are returned without the key.

A fresh CPCB National AQI Bulletin row for a supported NCR city is required before the dashboard switches to live-current decisions. City-level station coverage, the bulletin timestamp and the original source link are shown. The feed does not select a nearest monitor or claim a school-campus reading. When CPCB is missing or stale, the sample scenario stays active and is labeled as demo.

The app searches for and attempts to fetch a SAFAR forecast, but numeric forecast parsing is not implemented yet. The verified run could not retrieve SAFAR (`target_unreachable`), so the app explicitly says that no forward forecast is available and uses the latest city-level CPCB 24-hour value consistently for schedule review. That repeated observation is not labeled as a forecast. The CAQM/GRAP panel distinguishes a status found in official search material from a directly fetched order; a regional stage is context, not an automatic school closure or activity rule. If a later refresh fails, the previous CAQM result is marked last-known and stale rather than current.

## App controls

- **Live sync** checks CPCB, SAFAR and CAQM public sources. A live result records a source-backed decision for each scheduled activity and creates an in-app notification if recommendations, CAQM status or materially worsening conditions require review. API errors leave the demo scenario active.
- **Scenario** and **School settings** change clearly labeled illustrative AQI values. Saving a school profile applies its context and configurable thresholds and records changed decisions.
- **Customize platform** gives each browser a separate preference profile: Canopy/Midnight/high-contrast themes, preset or custom accent color, comfortable/compact density, DM Sans/system/Atkinson Hyperlegible type, text scaling, motion/accessibility settings, 12/24-hour schedule display, 3D airfield layer toggles, dashboard module visibility and startup page. These preferences save locally and reset without removing school data or history. Automatic TinyFish sync on page load is opt-in and defaults off; manual sync remains available.
- The activity planner supports editing and scheduling. Decision evidence links to its original source; the browser-local audit log can be searched and exported as CSV with basis, source URL, observed label, retrieval time and coverage.
- Alerts remain in-app previews. The prototype does not send email, WhatsApp or SMS, and does not use TinyFish's wallet-funded Agent or Browser APIs.
- Orbit the 3D campus by dragging. Desktop scroll zoom and mobile pinch zoom are supported. Continuous rendering pauses offscreen and honors reduced-motion settings.

## Data and safety boundary

This is a decision-support prototype, not medical advice and not an official school closure system. School thresholds are configurable demonstration defaults, not government rules. Confirm current source documents and school/competent-authority instructions before acting. Schedule, profile, alerts and decision history are stored in the browser; the ephemeral API cache is not a durable database.

TinyFish request and official source research notes are in [`docs/TINYFISH_API_NOTES.md`](docs/TINYFISH_API_NOTES.md). The open/pending delivery outcomes are tracked in [`TODO.md`](TODO.md).
