# TinyFish integration notes

Verified against TinyFish's official documentation and an end-to-end project refresh on 2026-10-24.

## API contract

- Search is `GET https://api.search.tinyfish.ai`; this integration sets `query`, `location=IN`, `language=en`, `include_domains`, and a task purpose. Search snippets identify possible sources; they are never treated as AQI values.
- Fetch is `POST https://api.fetch.tinyfish.ai` with `{"urls":[...],"format":"markdown","ttl":0}` for a live retrieval. A request can contain up to 10 URLs; per-URL failures are returned separately in `errors[]`.
- Both APIs authenticate with `X-API-Key`. The key is provided to the Express server via the WebDev protected secret `TINYFISH_API_KEY`; it is not used in browser code, exposed as a Vite variable or written to the repository.
- The project uses TinyFish Search and Fetch only; it does not call wallet-funded Agent or Browser endpoints. Requests use explicit timeouts; each per-IP refresh is rate-limited and responses are briefly cached to prevent accidental refresh loops.

## Source strategy

Search targets official CPCB, data.gov.in, SAFAR/IMD and CAQM domains. The official sources relevant to the UI are CPCB's AQI dashboard (`https://airquality.cpcb.gov.in/AQI_India/`), National AQI page (`https://cpcb.nic.in/National-Air-Quality-Index/`), CPCB's hourly data.gov.in listing (`https://www.data.gov.in/resource/real-time-air-quality-index-various-locations`) and CAQM's GRAP orders (`https://caqm.nic.in/landingpage/pages/grap/grap-orders`). The data.gov.in resource describes hourly granularity and warns that live field-instrument values can include abnormal readings. The CPCB dashboard and CAQM listing may be dynamically rendered, so the app retains provider URLs, observed/fetched times, extraction coverage and per-source error states; unsupported or stale data is not represented as live.

## Live retrieval evidence

The CPCB bulletin request URL `https://cpcb.gov.in/aqi_report.php` redirected to the official dated bulletin `https://cpcb.gov.in//upload/Downloads/AQI_Bulletin_20261024.pdf`. The server normalizes duplicate path slashes before exposing the link. TinyFish Fetch extracted the Delhi row: AQI 191, Moderate, PM2.5/PM10, 57/59 reporting stations, and the heading “Oct 24, 2026 @ 4 PM (Average of past 24 hours)”. This is a dated city-level 24-hour average—not a current hourly station reading or a campus sensor. The application parses the current bulletin at refresh and does not hardcode this value.

The end-to-end TinyFish Search result from the official CAQM domain reported “Stage-I ... Active & In Force”, effective 21 Oct 2026. The full-refresh result did not include text from the linked order PDF; the UI labels the listing as source-reported, exposes the official link and explicitly advises users to verify the order. A regional stage is not converted into a school closure rule. An official schedule may be linked separately, but school-specific instructions remain a human check. If a subsequent sync fails, the previous CAQM result remains visible only as “last known” and “stale”.

Search found SAFAR's official Delhi forecast PDF, but Fetch returned `target_unreachable`; a SAFAR live-page attempt also timed out. The SAFAR explanatory page is not a forecast feed, and numeric forecast parsing is not implemented yet. The UI says the forward forecast is unavailable and uses a current CPCB value consistently for activity review only when the CPCB bulletin row is fresh. It never holds the CPCB point flat and labels it as a forecast; synthetic curves are only used in demo mode. Source retrieval timestamps are recorded after TinyFish Fetch completes rather than before the provider work starts.

## Application boundaries

- `/api/tinyfish/refresh` is same-origin and validates the requested Delhi-NCR city, calls the two provider APIs from the server, and returns sanitized source results. The client receives no provider key.
- Only HTTPS URLs on the configured official-domain allowlist can be fetched or opened as evidence. The client displays city coverage, official source links, bulletin labels, retrieval times and feed warnings.
- A fresh parsed CPCB row is required for live-current decisions. Missing or stale evidence keeps the app in demo mode. A SAFAR forecast is treated separately and is used only if source-backed points are available.
- Recommendations are prototype school rules, not medical advice or official school orders. Schedule, thresholds, alerts and logs are stored in browser local storage. There is no durable school database or external email/SMS/WhatsApp integration.

## References

- [TinyFish Search overview](https://docs.tinyfish.ai/search-api)
- [TinyFish Search API reference](https://docs.tinyfish.ai/search-api/reference)
- [TinyFish Fetch overview](https://docs.tinyfish.ai/fetch-api)
- [TinyFish Fetch API reference](https://docs.tinyfish.ai/fetch-api/reference)
- [TinyFish authentication](https://docs.tinyfish.ai/authentication)
- [TinyFish guidance for coding agents](https://docs.tinyfish.ai/for-coding-agents)
- [CPCB National AQI dashboard](https://airquality.cpcb.gov.in/AQI_India/)
- [CPCB National Air Quality Index](https://cpcb.nic.in/National-Air-Quality-Index/)
- [CPCB real-time AQI data listing on data.gov.in](https://www.data.gov.in/resource/real-time-air-quality-index-various-locations)
- [CAQM GRAP orders](https://caqm.nic.in/landingpage/pages/grap/grap-orders)
