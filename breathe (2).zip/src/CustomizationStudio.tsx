import type { CSSProperties } from 'react';
import {
  Accessibility, Activity, Bell, Check, Eye, LayoutDashboard, Moon, Orbit, Palette,
  RotateCcw, ShieldCheck, Sparkles, Type, Wind,
} from 'lucide-react';
import {
  ACCENT_PRESETS,
  type DashboardPreferences,
  type PlatformPreferences,
  type ScenePreferences,
  type StartPage,
  type ThemeMode,
} from './preferences';

type Props = {
  preferences: PlatformPreferences;
  onChange: (next: PlatformPreferences) => void;
  onReset: () => void;
};

function ToggleRow({ title, detail, checked, onChange }: { title: string; detail: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <label className="custom-toggle-row">
      <span className="custom-toggle-copy"><strong>{title}</strong><small>{detail}</small></span>
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <span className="custom-toggle-switch" aria-hidden="true"><i /></span>
    </label>
  );
}

const themeOptions: Array<{ id: ThemeMode; title: string; detail: string; className: string }> = [
  { id: 'canopy', title: 'Canopy', detail: 'Original warm studio', className: 'theme-preview--canopy' },
  { id: 'midnight', title: 'Midnight', detail: 'Low-light command room', className: 'theme-preview--midnight' },
  { id: 'contrast', title: 'Contrast', detail: 'Sharper borders & text', className: 'theme-preview--contrast' },
];

const startPages: Array<{ id: StartPage; label: string }> = [
  { id: 'overview', label: 'Command center' },
  { id: 'planner', label: 'Activity planner' },
  { id: 'decisions', label: 'Decision log' },
  { id: 'advisories', label: 'Advisories & alerts' },
  { id: 'settings', label: 'School settings' },
];

export default function CustomizationStudio({ preferences, onChange, onReset }: Props) {
  const update = (patch: Partial<PlatformPreferences>) => onChange({ ...preferences, ...patch });
  const updateScene = (patch: Partial<ScenePreferences>) => update({ scene: { ...preferences.scene, ...patch } });
  const updateDashboard = (patch: Partial<DashboardPreferences>) => update({ dashboard: { ...preferences.dashboard, ...patch } });
  const accentStyle = { '--preview-accent': preferences.accentColor } as CSSProperties;

  return (
    <div className="subpage customization-page">
      <div className="subpage-heading customization-heading">
        <div><p className="eyebrow">YOUR WORKSPACE · SAVED ON THIS DEVICE</p><h1>Customize platform</h1><p>Tune the command center to your team. Changes preview immediately and never alter school thresholds or decision history.</p></div>
        <button className="button button--quiet customization-reset" onClick={onReset}><RotateCcw size={14} /> Restore platform defaults</button>
      </div>

      <section className="surface customization-preview" style={accentStyle}>
        <div className="customization-preview-brand"><div className="customization-preview-mark"><Wind size={19} /></div><div><span>LIVE PREVIEW</span><strong>BreatheSafe command center</strong></div></div>
        <div className="customization-preview-sample"><span className="customization-preview-badge"><i /> AIR-SAFETY STATUS</span><strong>Air-aware decisions<br />before the first bell.</strong><button className="customization-preview-button"><Check size={13} /> Review today’s plan</button></div>
        <div className="customization-preview-meta"><span>{preferences.theme} theme</span><i /><span>{preferences.density} layout</span><i /><span>{preferences.textScale}% type</span></div>
      </section>

      <div className="customization-sections">
        <section className="surface customization-card">
          <div className="customization-card-heading"><span className="customization-card-icon"><Palette size={17} /></span><div><h2>Appearance & brand</h2><p>Choose the visual tone and the accent used by key controls.</p></div></div>
          <div className="customization-field"><span className="customization-label">Interface theme</span><div className="theme-choice-row">{themeOptions.map((option) => <button key={option.id} className={`theme-choice ${preferences.theme === option.id ? 'theme-choice--selected' : ''}`} onClick={() => update({ theme: option.id })} aria-pressed={preferences.theme === option.id}><span className={`theme-preview ${option.className}`}><i /><i /><i /></span><strong>{option.title}</strong><small>{option.detail}</small></button>)}</div></div>
          <div className="customization-field"><div className="customization-label-row"><span className="customization-label">Signature accent</span><span className="customization-current-accent"><i style={{ background: preferences.accentColor }} />{preferences.accentColor.toUpperCase()}</span></div><div className="accent-choice-row">{ACCENT_PRESETS.map((accent) => <button key={accent.value} className={`accent-swatch ${preferences.accentColor.toLowerCase() === accent.value ? 'accent-swatch--selected' : ''}`} style={{ '--swatch': accent.value } as CSSProperties} onClick={() => update({ accentColor: accent.value })} aria-label={`${accent.name} accent`} aria-pressed={preferences.accentColor.toLowerCase() === accent.value} title={accent.name} />)}<label className="accent-custom-control"><input type="color" value={preferences.accentColor} onChange={(event) => update({ accentColor: event.target.value })} aria-label="Choose a custom accent color" /><span>Custom</span></label></div></div>
        </section>

        <section className="surface customization-card">
          <div className="customization-card-heading"><span className="customization-card-icon"><Type size={17} /></span><div><h2>Typography & layout</h2><p>Set a reading style and the amount of breathing room.</p></div></div>
          <div className="customization-two-fields"><label className="customization-field"><span className="customization-label">Typeface</span><select value={preferences.font} onChange={(event) => update({ font: event.target.value as PlatformPreferences['font'] })}><option value="dm-sans">DM Sans · balanced</option><option value="system">System · native</option><option value="atkinson">Atkinson Hyperlegible · accessible</option></select></label><label className="customization-field"><span className="customization-label">Layout density</span><select value={preferences.density} onChange={(event) => update({ density: event.target.value as PlatformPreferences['density'] })}><option value="comfortable">Comfortable · more space</option><option value="compact">Compact · more on screen</option></select></label></div>
          <div className="customization-field text-scale-field"><div className="customization-label-row"><span className="customization-label">Text size</span><strong>{preferences.textScale}%</strong></div><input type="range" min="90" max="120" step="10" value={preferences.textScale} onChange={(event) => update({ textScale: Number(event.target.value) as PlatformPreferences['textScale'] })} aria-label="Text size percentage" /><div className="scale-range-labels"><span>Smaller</span><span>Default</span><span>Larger</span></div></div>
        </section>

        <section className="surface customization-card">
          <div className="customization-card-heading"><span className="customization-card-icon"><Accessibility size={17} /></span><div><h2>Accessibility & motion</h2><p>Reduce movement, improve contrast and choose a familiar clock.</p></div></div>
          <ToggleRow title="High-contrast controls" detail="Stronger outlines and clearer text hierarchy." checked={preferences.highContrast} onChange={(highContrast) => update({ highContrast })} />
          <ToggleRow title="Reduce motion" detail="Pause ornamental motion and respect reduced-motion preference." checked={preferences.reducedMotion} onChange={(reducedMotion) => update({ reducedMotion })} />
          <label className="customization-select-row"><span><strong>Clock display</strong><small>Schedule and time labels</small></span><select value={preferences.clockFormat} onChange={(event) => update({ clockFormat: event.target.value as PlatformPreferences['clockFormat'] })}><option value="12h">12-hour · AM/PM</option><option value="24h">24-hour</option></select></label>
        </section>

        <section className="surface customization-card">
          <div className="customization-card-heading"><span className="customization-card-icon"><Orbit size={17} /></span><div><h2>3D atmosphere</h2><p>Keep the campus visualization detailed—or make it quieter and lighter.</p></div></div>
          <div className="customization-toggle-list"><ToggleRow title="Floating particles" detail="Animated airborne particulate field." checked={preferences.scene.particles} onChange={(particles) => updateScene({ particles })} /><ToggleRow title="Airflow ribbons" detail="Orbiting flow paths around the school." checked={preferences.scene.airflow} onChange={(airflow) => updateScene({ airflow })} /><ToggleRow title="Protective safety field" detail="AQI-colored wireframe canopy around campus." checked={preferences.scene.safetyField} onChange={(safetyField) => updateScene({ safetyField })} /><ToggleRow title="Haze layers" detail="Subtle volumetric-style haze layers." checked={preferences.scene.haze} onChange={(haze) => updateScene({ haze })} /><ToggleRow title="Automatic orbit" detail="Slow camera rotation; direct touch/drag controls remain available." checked={preferences.scene.autoRotate && !preferences.reducedMotion} onChange={(autoRotate) => updateScene({ autoRotate })} /></div>
          <div className="customization-note"><Moon size={14} /> Reduced-motion and system accessibility settings can still pause continuous animation.</div>
        </section>

        <section className="surface customization-card">
          <div className="customization-card-heading"><span className="customization-card-icon"><LayoutDashboard size={17} /></span><div><h2>Command center modules</h2><p>Show only the panels that matter to this team.</p></div></div>
          <div className="customization-toggle-list"><ToggleRow title="3D school airfield" detail="Interactive campus visualization on the command center." checked={preferences.dashboard.scene} onChange={(scene) => updateDashboard({ scene })} /><ToggleRow title="AQI trend card" detail="Forecast/sample curve and threshold context." checked={preferences.dashboard.trend} onChange={(trend) => updateDashboard({ trend })} /><ToggleRow title="Today’s activity schedule" detail="Upcoming school activities and their recommendations." checked={preferences.dashboard.activities} onChange={(activities) => updateDashboard({ activities })} /><ToggleRow title="CAQM / GRAP source card" detail="Regional source status and verification caveats." checked={preferences.dashboard.advisory} onChange={(advisory) => updateDashboard({ advisory })} /><ToggleRow title="Recent in-app alerts" detail="Latest staff/family notices in the command center." checked={preferences.dashboard.alerts} onChange={(alerts) => updateDashboard({ alerts })} /></div>
        </section>

        <section className="surface customization-card customization-card--workflow">
          <div className="customization-card-heading"><span className="customization-card-icon"><Sparkles size={17} /></span><div><h2>Startup & live data</h2><p>Control where the app opens and whether loading it makes a live-source request.</p></div></div>
          <label className="customization-select-row"><span><strong>Default page</strong><small>Used at the next visit</small></span><select value={preferences.startPage} onChange={(event) => update({ startPage: event.target.value as StartPage })}>{startPages.map((page) => <option value={page.id} key={page.id}>{page.label}</option>)}</select></label>
          <ToggleRow title="Check live sources on launch" detail="Off by default. When enabled, a page load calls the TinyFish relay; manual live sync stays available either way." checked={preferences.autoSyncOnLaunch} onChange={(autoSyncOnLaunch) => update({ autoSyncOnLaunch })} />
          <div className="customization-note"><ShieldCheck size={14} /> Preferences stay in this browser. Resetting them does not delete school details, activities, alerts or decisions.</div>
        </section>
      </div>

      <div className="customization-footer"><span><Eye size={15} /> Updates are applied as you choose them.</span><button className="button button--outline" onClick={onReset}><RotateCcw size={14} /> Reset only platform preferences</button><span><Bell size={14} /> No school data or history is removed.</span><Activity size={14} className="customization-footer-mark" /></div>
    </div>
  );
}
