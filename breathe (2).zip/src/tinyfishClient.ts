import type { TinyFishSnapshot } from './types';

export async function refreshTinyFishSources(location: string): Promise<TinyFishSnapshot> {
  const response = await fetch('/api/tinyfish/refresh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ location }),
  });
  const payload = await response.json().catch(() => ({})) as Partial<TinyFishSnapshot> & { error?: string };
  if (!response.ok) throw new Error(payload.error ?? `Live source refresh failed (${response.status}).`);
  return payload as TinyFishSnapshot;
}
