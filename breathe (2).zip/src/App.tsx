import { lazy, Suspense, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import {
  Activity as ActivityIcon,
  ArrowDownRight,
  ArrowRight,
  Bell,
  Check,
  ChevronDown,
  ChevronRight,
  Clock3,
  CloudFog,
  Download,
  ExternalLink,
  Filter,
  Gauge,
  History,
  Home,
  Info,
  MapPin,
  Menu,
  MoreHorizontal,
  Paintbrush,
  Plus,
  Radio,
  RefreshCw,
  Search,
  Settings2,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TriangleAlert,
  Wind,
  X,
  Zap,
} from 'lucide-react';
const AtmosphereScene = lazy(() => import('./AtmosphereScene'));
import { buildInitialLog, DEFAULT_ACTIVITIES, DEFAULT_AQI, DEFAULT_ALERTS, DEFAULT_PROFILE, forecastForAqi, readStored } from './demoData';
import { classifyBand, evaluateActivity } from './decisionEngine';
import type { Activity, ActivityKind, AppAlert, Decision, DecisionEvidence, DecisionStatus, ParticipantGroup, SchoolProfile, TinyFishSnapshot, Venue, ViewId } from './types';
import { refreshTinyFishSources } from './tinyfishClient';
import CustomizationStudio from './CustomizationStudio';
import { DEFAULT_PREFERENCES, loadPlatformPreferences, PREFERENCES_KEY, type ClockFormat, type PlatformPreferences } from './preferences';

const STORE = {
  aqi: 'breathesafe-demo-aqi-v1',
  profile: 'breathesafe-school-profile-v1',
  activities: 'breathesafe-activities-v1',
  log: 'breathesafe-decision-log-v1',
  alerts: 'breathesafe-alerts-v1',
  targets: 'breathesafe-alert-targets-v1',
};

const navItems: Array<{ id: ViewId; label: string; icon: typeof Home }> = [
  { id: 'overview', label: 'Command center', icon: Home },
  { id: 'planner', label: 'Activity planner', icon: ActivityIcon },
  { id: 'decisions', label: 'Decision log', icon: History },
  { id: 'advisories', label: 'Advisories & alerts', icon: ShieldAlert },
  { id: 'settings', label: 'School settings', icon: Settings2 },
  { id: 'customize', label: 'Customize platform', icon: Paintbrush },
];

function pad(value: number) {
  return String(value).padStart(2, '0');
}

function currentTime() {
  return new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date());
}

function formatClock(value: string, clockFormat: ClockFormat = '12h') {
  const [hours, minutes] = value.split(':').map(Number);
  if (clockFormat === '24h') return `${pad(hours)}:${pad(minutes)}`;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  return `${hours % 12 || 12}:${pad(minutes)} ${suffix}`;
}

function shortDate() {
  return new Intl.DateTimeFormat('en-IN', { weekday: 'long', day: 'numeric', month: 'short', timeZone: 'Asia/Kolkata' }).format(new Date());
}

function formatSourceTime(value?: string | null) {
  if (!value) return 'time not reported';
  return new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }).format(new Date(value));
}

function statusClass(status: DecisionStatus | 'INFO') {
  if (status === 'GO') return 'status-go';
  if (status === 'MODIFY') return 'status-modify';
  if (status === 'NO-GO') return 'status-nogo';
  return 'status-info';
}

function decisionAlertStatus(changes: Decision[]): DecisionStatus {
  if (changes.some((decision) => decision.status === 'NO-GO')) return 'NO-GO';
  if (changes.some((decision) => decision.status === 'MODIFY')) return 'MODIFY';
  return 'GO';
}

function aqiName(aqi: number) {
  if (aqi <= 50) return 'Good';
  if (aqi <= 100) return 'Satisfactory';
  if (aqi <= 200) return 'Moderate';
  if (aqi <= 300) return 'Poor';
  if (aqi <= 400) return 'Very poor';
  return 'Severe';
}

function timeLabel(value: string) {
  const hour = Number(value.slice(0, 2));
  if (hour < 10) return 'Morning';
  if (hour < 14) return 'Midday';
  return 'Afternoon';
}

function getActivityAqi(activity: Activity, points: ReturnType<typeof forecastForAqi>, fallback: number) {
  const exact = points.find((point) => point.time === activity.time);
  if (exact) return exact.aqi;
  const [hour, minute] = activity.time.split(':').map(Number);
  const target = hour * 60 + minute;
  const closest = points.reduce((best, point) => {
    const [h, m] = point.time.split(':').map(Number);
    return Math.abs(h * 60 + m - target) < Math.abs(Number(best.time.slice(0, 2)) * 60 + Number(best.time.slice(3)) - target) ? point : best;
  }, points[0]);
  return closest?.aqi ?? fallback;
}

function StatusTag({ status, compact = false }: { status: DecisionStatus; compact?: boolean }) {
  const Icon = status === 'GO' ? Check : status === 'MODIFY' ? ArrowRight : TriangleAlert;
  return <span className={`status-tag ${statusClass(status)} ${compact ? 'status-tag--compact' : ''}`}><Icon size={compact ? 12 : 14} strokeWidth={2.2} />{status}</span>;
}

function ForecastChart({ points, isLive, isForecast, moderateMax }: { points: ReturnType<typeof forecastForAqi>; isLive: boolean; isForecast: boolean; moderateMax: number }) {
  const width = 640;
  const height = 174;
  const left = 12;
  const right = 18;
  const top = 19;
  const bottom = 30;
  const min = Math.min(0, ...points.map((point) => point.aqi - 70));
  const max = Math.max(350, ...points.map((point) => point.aqi + 20));
  const x = (index: number) => left + (index / Math.max(points.length - 1, 1)) * (width - left - right);
  const y = (value: number) => top + ((max - value) / (max - min)) * (height - top - bottom);
  const curve = points.map((point, index) => `${index ? 'L' : 'M'} ${x(index)} ${y(point.aqi)}`).join(' ');
  const area = `${curve} L ${x(points.length - 1)} ${height - bottom} L ${x(0)} ${height - bottom} Z`;
  return (
    <div className="forecast-chart-wrap">
      <div className="chart-legend"><span><i className="legend-dot legend-dot--mint" />{isForecast ? 'SAFAR live forecast · source-linked' : isLive ? 'Latest CPCB reading · held flat, not a forecast' : 'AQI forecast · demo scenario'}</span><span className="chart-threshold"><i />School elevated threshold · AQI {moderateMax}</span></div>
      <svg className="forecast-chart" viewBox={`0 0 ${width} ${height}`} role="img" aria-label={isForecast ? 'SAFAR published Delhi forecast points with source and retrieval time' : isLive ? 'Latest verified CPCB city reading repeated across activity times as a conservative input; it is not a forecast' : 'Illustrative demo forecast AQI line trending lower through the afternoon'}>
        <defs><linearGradient id="forecastArea" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#f0a578" stopOpacity=".24" /><stop offset="100%" stopColor="#f0a578" stopOpacity="0" /></linearGradient><linearGradient id="forecastLine" x1="0" x2="1" y1="0" y2="0"><stop offset="0%" stopColor="#ff9b76" /><stop offset="53%" stopColor="#efc779" /><stop offset="100%" stopColor="#8be1bb" /></linearGradient></defs>
        {[0, 1, 2].map((row) => <g key={row}><line x1={left} x2={width - right} y1={top + row * 45} y2={top + row * 45} className="chart-grid-line" /><text x={left} y={top + row * 45 - 5} className="chart-axis-label">{Math.round(max - (max - min) * (row / 2))}</text></g>)}
        <line x1={left} x2={width - right} y1={y(moderateMax)} y2={y(moderateMax)} className="chart-threshold-line" />
        <path d={area} fill="url(#forecastArea)" />
        <path d={curve} fill="none" stroke="url(#forecastLine)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((point, index) => <g key={point.time}><circle cx={x(index)} cy={y(point.aqi)} r="7.5" fill="#101d19" stroke={point.aqi > 300 ? '#ff9677' : point.aqi > 200 ? '#e7b770' : '#9ce7c7'} strokeWidth="2.5" /><circle cx={x(index)} cy={y(point.aqi)} r="2.5" fill="#f1f3e4" /><text x={x(index)} y={height - 8} textAnchor="middle" className="chart-time-label">{point.time}</text><title>{point.time}: AQI {point.aqi} · {isForecast ? 'SAFAR published forecast' : isLive ? 'current CPCB value, not a forecast' : 'demo value'}</title></g>)}
      </svg>
      <div className="chart-footnote">{isForecast ? <><span><span className="tiny-dot tiny-dot--mint" />{points[0]?.label || 'SAFAR public forecast'}</span><span>Model forecast · not a station observation</span></> : isLive ? <><span><span className="tiny-dot tiny-dot--mint" />Official city bulletin · {points[0]?.label}</span><span>Forward forecast unavailable · held constant for assessment only</span></> : <><span><span className="tiny-dot tiny-dot--coral" />Peak window around 8 AM</span><span><span className="tiny-dot tiny-dot--mint" />Conditions ease into afternoon · demo only</span></>}</div>
    </div>
  );
}

function ActivityCard({ activity, decision, onOpen, onEdit, clockFormat }: {
  activity: Activity;
  decision: Decision;
  clockFormat: ClockFormat;
  onOpen: (decision: Decision) => void;
  onEdit: (activity: Activity) => void;
}) {
  const Icon = activity.kind === 'Assembly' ? Wind : activity.kind === 'Competition' ? Zap : ActivityIcon;
  return (
    <article className="activity-row">
      <div className="activity-time"><strong>{formatClock(activity.time, clockFormat)}</strong><span>{timeLabel(activity.time)}</span></div>
      <div className="activity-icon"><Icon size={16} /></div>
      <button className="activity-main" onClick={() => onOpen(decision)}><span className="activity-title">{activity.title}</span><span className="activity-subtitle">{activity.group} <span>·</span> {activity.venue} <span>·</span> {decision.dataBasis === 'live-current' ? 'latest AQI' : 'forecast AQI'} {decision.aqi}</span></button>
      <div className="activity-action"><StatusTag status={decision.status} compact /><span className="activity-action-text">{decision.action}</span></div>
      <div className="row-actions"><button aria-label={`Edit ${activity.title}`} onClick={() => onEdit(activity)}><MoreHorizontal size={17} /></button><button aria-label={`View details for ${activity.title}`} onClick={() => onOpen(decision)}><ChevronRight size={16} /></button></div>
    </article>
  );
}

function ActivityEditor({ initial, onSave, onClose }: { initial?: Activity; onSave: (activity: Activity) => void; onClose: () => void }) {
  const [draft, setDraft] = useState<Activity>(initial ?? {
    id: `event-${Date.now()}`,
    title: '',
    kind: 'PE',
    time: '11:00',
    group: 'Primary (6–11)',
    venue: 'Outdoor',
    details: '',
  });
  const update = <K extends keyof Activity>(key: K, value: Activity[K]) => setDraft((current) => ({ ...current, [key]: value }));
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <form className="modal-card editor-modal" onSubmit={(event) => { event.preventDefault(); if (draft.title.trim()) onSave({ ...draft, title: draft.title.trim() }); }}>
        <div className="modal-header"><div><p className="eyebrow">SCHOOL-DAY SCHEDULE</p><h2>{initial ? 'Edit activity' : 'Add activity'}</h2></div><button type="button" className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <label className="field-label">Activity name<input autoFocus required value={draft.title} onChange={(event) => update('title', event.target.value)} placeholder="e.g. Class 6 athletics" /></label>
        <div className="form-pair"><label className="field-label">Activity type<select value={draft.kind} onChange={(event) => update('kind', event.target.value as ActivityKind)}>{(['Assembly', 'PE', 'Practice', 'Competition'] as ActivityKind[]).map((kind) => <option key={kind}>{kind}</option>)}</select></label><label className="field-label">Start time<input type="time" value={draft.time} onChange={(event) => update('time', event.target.value)} /></label></div>
        <div className="form-pair"><label className="field-label">Participant group<select value={draft.group} onChange={(event) => update('group', event.target.value as ParticipantGroup)}>{(['Primary (6–11)', 'Middle / Senior', 'Competition team'] as ParticipantGroup[]).map((group) => <option key={group}>{group}</option>)}</select></label><label className="field-label">Venue<select value={draft.venue} onChange={(event) => update('venue', event.target.value as Venue)}><option>Outdoor</option><option>Indoor</option></select></label></div>
        <label className="field-label">Context or staff note<textarea value={draft.details} onChange={(event) => update('details', event.target.value)} rows={2} placeholder="Optional context included with the decision" /></label>
        <div className="modal-actions"><button type="button" className="button button--quiet" onClick={onClose}>Cancel</button><button type="submit" className="button button--primary"><Check size={15} /> Save activity</button></div>
      </form>
    </div>
  );
}

function DecisionModal({ decision, onClose, clockFormat }: { decision: Decision; onClose: () => void; clockFormat: ClockFormat }) {
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <div className="modal-card decision-modal">
        <div className="modal-header"><div><p className="eyebrow">DECISION EVIDENCE · {formatClock(decision.time, clockFormat)}</p><h2>{decision.title}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button></div>
        <div className="decision-modal-status"><StatusTag status={decision.status} /><span>{decision.action}</span></div>
        <div className="detail-stat-grid"><div><span>{decision.dataBasis === 'live-current' ? 'Latest AQI · CPCB' : decision.dataBasis === 'live-forecast' ? 'SAFAR forecast AQI' : 'Forecast AQI · demo'}</span><strong>{decision.aqi}</strong></div><div><span>Air band</span><strong>{decision.band}</strong></div><div><span>Group</span><strong>{decision.group}</strong></div><div><span>Venue</span><strong>{decision.venue}</strong></div></div>
        <div className="detail-section"><h3><Sparkles size={15} /> Why this decision</h3><ul>{decision.reasons.map((reason, index) => <li key={`${index}-${reason}`}>{reason}</li>)}</ul></div>
        <div className="provenance-box"><div className="provenance-icon"><Info size={16} /></div><div><strong>Data provenance</strong><p>{decision.source}</p>{decision.observationLabel && <p>Observed {decision.observationLabel}{decision.dataCoverage ? ` · ${decision.dataCoverage}` : ''}{decision.sourceCheckedAt ? ` · retrieved ${formatSourceTime(decision.sourceCheckedAt)}` : ''}</p>}{decision.sourceUrl && <a className="source-link" href={decision.sourceUrl} target="_blank" rel="noreferrer">Open original source <ExternalLink size={13} /></a>}{decision.profileSnapshot ? <p>Profile at decision time: {decision.profileSnapshot.schoolName} · {decision.profileSnapshot.district}. Thresholds: GO ≤{decision.profileSnapshot.safeMax}; elevated ≤{decision.profileSnapshot.moderateMax}; high ≤{decision.profileSnapshot.highMax}; NO-GO {decision.profileSnapshot.highMax + 1}+ AQI. · decision engine version 1.1</p> : <p>Threshold snapshot unavailable for this older record. · decision engine version 1.1</p>}</div></div>
        <div className="modal-footer-note"><Clock3 size={13} /> Recorded {new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }).format(new Date(decision.recordedAt))} IST</div>
      </div>
    </div>
  );
}

function NotificationPopover({ alerts, onRead, onClose, onSeeAll }: { alerts: AppAlert[]; onRead: (id: string) => void; onClose: () => void; onSeeAll: () => void }) {
  return (
    <div className="notification-popover">
      <div className="popover-head"><div><p className="eyebrow">LOCAL IN-APP ALERTS</p><h3>Updates for your school</h3></div><button className="icon-button icon-button--small" onClick={onClose} aria-label="Close notifications"><X size={15} /></button></div>
      <div className="popover-list">{alerts.slice(0, 5).map((alert) => <button className={`notification-item ${alert.read ? 'notification-item--read' : ''}`} key={alert.id} onClick={() => onRead(alert.id)}><span className={`notification-icon ${statusClass(alert.status)}`}>{alert.status === 'NO-GO' ? <TriangleAlert size={15} /> : alert.status === 'MODIFY' ? <ArrowRight size={15} /> : <Info size={15} />}</span><span className="notification-copy"><strong>{alert.title}</strong><small>{alert.detail}</small><small className="notification-time">{alert.time}</small></span>{!alert.read && <i className="unread-dot" />}</button>)}{alerts.length === 0 && <div className="empty-small">No alerts yet. Simulate a forecast update to create one.</div>}</div>
      <div className="popover-foot"><button className="text-button" onClick={onSeeAll}>See all alerts <ArrowRight size={13} /></button><span>Demo only · no messages sent externally</span></div>
    </div>
  );
}

function Overview({
  aqi, profile, activities, decisions, alerts, points, isLive, hasForecast, snapshot, snapshotStale, liveLoading, liveError, preferences, onSyncLive, onOpenDecision, onEditActivity, onShowAlerts, onNavigate, onAdd,
}: {
  aqi: number; profile: SchoolProfile; activities: Activity[]; decisions: Decision[]; alerts: AppAlert[]; points: ReturnType<typeof forecastForAqi>;
  isLive: boolean; hasForecast: boolean; snapshot: TinyFishSnapshot | null; snapshotStale: boolean; liveLoading: boolean; liveError: string; preferences: PlatformPreferences; onSyncLive: () => void;
  onOpenDecision: (decision: Decision) => void; onEditActivity: (activity: Activity) => void;
  onShowAlerts: () => void; onNavigate: (view: ViewId) => void; onAdd: () => void;
}) {
  const currentBand = classifyBand(aqi, profile);
  const criticalCount = decisions.filter((decision) => decision.status === 'NO-GO').length;
  const modifyCount = decisions.filter((decision) => decision.status === 'MODIFY').length;
  const nextCleaner = points.find((point) => point.aqi <= profile.moderateMax);
  const coreModuleCount = Number(preferences.dashboard.trend) + Number(preferences.dashboard.activities);
  const lowerModuleCount = Number(preferences.dashboard.advisory) + Number(preferences.dashboard.alerts);
  return (
    <>
      <div className="page-heading"><div><div className="breadcrumb"><span>{profile.district}</span><ChevronRight size={12} /><span>School operations</span></div><h1>One clear call.<br /><span>Before the first bell.</span></h1><p>Air-aware decisions for every activity on the school day.</p></div><div className="heading-date"><span className="date-kicker">TODAY · SCHOOL DAY</span><strong>{shortDate()}</strong><span className="demo-location"><MapPin size={14} />{profile.schoolName} · {profile.district}</span></div></div>

      <section className={`hero-panel surface ${preferences.dashboard.scene ? '' : 'hero-panel--scene-hidden'}`}>
        <div className="hero-copy">
          <div className="hero-kicker"><span className="hero-kicker-icon"><CloudFog size={15} /></span> AIR-SAFETY STATUS <span className={`demo-pill ${isLive ? 'demo-pill--live' : ''}`}>{liveLoading ? 'SYNCING TINYFISH' : isLive ? 'LIVE · CPCB CITY BULLETIN' : snapshot ? 'PARTIAL · DEMO AQI' : 'DEMO SCENARIO'}</span></div>
          <div className="hero-reading"><strong>{aqi}</strong><div><span className="hero-reading-unit">AQI</span><span className={`category-label ${aqi > 300 ? 'category-label--rose' : aqi > 200 ? 'category-label--amber' : 'category-label--mint'}`}><i />{aqiName(aqi)}</span></div></div>
          <p className="hero-status-message">{aqi > profile.highMax ? 'Pause outdoor exertion. Choose an indoor plan.' : aqi > profile.moderateMax ? 'Modify high-exertion plans and protect younger students.' : aqi > profile.safeMax ? 'Keep sessions shorter for primary students.' : isLive ? 'Latest CPCB city reading is within the school’s low-exposure band.' : 'Current demo scenario is within the school’s safe band.'}</p>
          <div className="hero-context"><span><MapPin size={14} />{isLive ? `${snapshot?.currentAqi?.city ?? profile.district} · ${snapshot?.currentAqi?.coverage ?? 'CPCB city aggregate'}` : profile.station}</span><span className="context-separator" /><span><Clock3 size={14} />{isLive ? `Observed · ${snapshot?.currentAqi?.observationLabel ?? 'CPCB bulletin'}` : 'Demo forecast window · 6:30 AM–6 PM'}</span></div>
          <div className="hero-actions"><button className="button button--primary" onClick={() => onNavigate('planner')}><ActivityIcon size={15} /> Review today’s plan <ArrowRight size={15} /></button><button className="button button--outline" onClick={() => onNavigate('decisions')}>Open decision log <ChevronRight size={15} /></button></div>
          <div className={`hero-data-note ${isLive ? 'hero-data-note--live' : ''}`}>
            {isLive && snapshot?.currentAqi ? <><Info size={13} /><span>{snapshot.currentAqi.sourceName} · city average · fetched {formatSourceTime(snapshot.fetchedAt)}</span><a className="source-link" href={snapshot.currentAqi.sourceUrl} target="_blank" rel="noreferrer">Open bulletin <ExternalLink size={12} /></a></> : <><Info size={13} /><span>{liveLoading ? 'TinyFish is checking CPCB, SAFAR and CAQM. Demo values remain active until a fresh CPCB row is verified.' : liveError || 'Sample values from the hackathon scenario · not a live CPCB reading'}</span><button className="source-inline-action" onClick={onSyncLive} disabled={liveLoading}>{liveLoading ? 'Syncing…' : 'Sync TinyFish'}</button></>}
          </div>
        </div>
        {preferences.dashboard.scene && <div className="hero-visual"><Suspense fallback={<div className="scene-loading"><div className="scene-loading-orbit" /><span>Building the school air-field…</span></div>}><AtmosphereScene aqi={aqi} settings={preferences.scene} reducedMotion={preferences.reducedMotion} /></Suspense><div className="scene-aqi-card"><div className="scene-aqi-dot" /><div><span>{isLive ? `${snapshot?.currentAqi?.city ?? 'CPCB'} · CITY AVG` : 'DEMO STATION'}</span><strong>{aqi} <small>AQI</small></strong></div><span className="scene-aqi-trend">{isLive ? 'OFFICIAL BULLETIN' : <><ArrowDownRight size={14} /> demo curve</>}</span></div><div className="scene-scale"><span>SAFE</span><div><i className="scale-mint" /><i className="scale-yellow" /><i className="scale-amber" /><i className="scale-rose" /></div><span>CRITICAL</span></div></div>}
      </section>

      <div className="metrics-strip">
        <article className="metric-card"><div className="metric-icon metric-icon--rose"><ShieldAlert size={17} /></div><div className="metric-label">Needs action</div><strong>{criticalCount}<small> activities</small></strong><span>Outdoor plans in NO-GO band</span></article>
        <article className="metric-card"><div className="metric-icon metric-icon--amber"><SlidersHorizontal size={17} /></div><div className="metric-label">Modify plan</div><strong>{modifyCount}<small> activities</small></strong><span>Safer alternatives recommended</span></article>
        <article className="metric-card"><div className="metric-icon metric-icon--mint"><Gauge size={17} /></div><div className="metric-label">Current band</div><strong className="metric-band">{currentBand}</strong><span>Thresholds set by this school</span></article>
        <article className="metric-card metric-card--window"><div className="metric-icon metric-icon--blue"><Clock3 size={17} /></div><div className="metric-label">{hasForecast ? 'Verified cleaner window' : isLive ? 'Forward forecast' : 'Cleaner window'}</div><strong>{hasForecast && nextCleaner ? formatClock(nextCleaner.time) : '—'}</strong><span>{hasForecast && nextCleaner ? `AQI ${nextCleaner.aqi} · SAFAR forecast` : isLive && !hasForecast ? 'Unavailable · not inferred' : nextCleaner ? `AQI ${nextCleaner.aqi} · demo forecast` : hasForecast ? 'No safer window in published points' : 'No safer window in scenario'}</span></article>
      </div>

      {coreModuleCount > 0 && <div className={`dashboard-grid ${coreModuleCount === 1 ? 'dashboard-grid--single' : ''}`}>
        {preferences.dashboard.trend && <section className="surface forecast-panel"><div className="panel-heading"><div><p className="eyebrow">{hasForecast ? 'SAFAR LIVE FORECAST · SOURCE-LINKED' : isLive ? 'CURRENT CPCB CITY AQI · NO VERIFIED FORECAST' : 'THE NEXT 12 HOURS · SAMPLE CURVE'}</p><h2>{hasForecast ? 'A published model forecast, not a station measurement.' : isLive ? 'A measured reading, not a projection.' : 'When the air shifts, the plan should too.'}</h2></div><button className="icon-button" onClick={() => onNavigate('settings')} aria-label="Open profile settings"><Settings2 size={17} /></button></div><ForecastChart points={points} isLive={isLive} isForecast={hasForecast} moderateMax={profile.moderateMax} /></section>}
        {preferences.dashboard.activities && <section className="surface day-panel"><div className="panel-heading"><div><p className="eyebrow">{shortDate().toUpperCase()} · {hasForecast ? 'LIVE SAFAR FORECAST' : isLive ? 'LIVE AQI SNAPSHOT' : 'DEMO PLAN'}</p><h2>{hasForecast ? 'Forecast-based activity assessments' : isLive ? 'Current activity assessments' : 'Today’s activity calls'}</h2></div><button className="text-button" onClick={() => onNavigate('planner')}>Open planner <ArrowRight size={14} /></button></div><div className="activity-list">{activities.slice().sort((a, b) => a.time.localeCompare(b.time)).map((activity) => { const decision = decisions.find((item) => item.activityId === activity.id) ?? decisions[0]; return decision ? <ActivityCard key={activity.id} activity={activity} decision={decision} clockFormat={preferences.clockFormat} onOpen={onOpenDecision} onEdit={onEditActivity} /> : null; })}{activities.length === 0 && <div className="empty-block"><ActivityIcon size={22} /><strong>No activities scheduled</strong><span>Add the first event to run its AQI decision.</span><button className="button button--outline" onClick={onAdd}><Plus size={15} /> Add activity</button></div>}</div><button className="add-activity-line" onClick={onAdd}><Plus size={14} /> Add activity to the day</button></section>}
      </div>}

      {lowerModuleCount > 0 && <div className={`lower-grid ${lowerModuleCount === 1 ? 'lower-grid--single' : ''}`}>
        {preferences.dashboard.advisory && <section className="surface advisory-callout"><div className="advisory-symbol"><ShieldCheck size={20} /></div><div className="advisory-copy"><p className="eyebrow">CAQM / GRAP · OFFICIAL SOURCE</p><h2>{snapshotStale && snapshot?.advisory.stage ? `Last known ${snapshot.advisory.stage} listing · stale` : snapshot?.advisory.status === 'active' ? `${snapshot.advisory.stage ?? 'GRAP stage'} listing says active · verify the order.` : snapshot?.advisory.status === 'order-found' ? `${snapshot?.advisory.stage ?? 'GRAP'} order found · force unverified.` : snapshot ? 'Current CAQM stage could not be verified.' : 'CAQM source has not been checked yet.'}</h2><p>{profile.advisoryActive ? 'The local competition override remains a school demo rule, not a CAQM order. ' : ''}{snapshotStale ? `A refresh failed: ${liveError} The previous result checked ${formatSourceTime(snapshot?.fetchedAt)} is not confirmation of current status.` : snapshot?.advisory.status === 'active' ? `${snapshot.advisory.effectiveDate ? `Effective ${snapshot.advisory.effectiveDate}. ` : ''}This regional stage is context only; verify the linked order and school instruction before acting.` : snapshot?.advisory.status === 'order-found' ? 'A retrieved order is not sufficient to conclude it is still in force. Review the original source.' : snapshot ? 'Check the advisory source panel for its retrieval result and any warnings.' : 'Sync TinyFish Search + Fetch for current public CAQM/GRAP source material.'}</p></div><button className="button button--outline" onClick={() => onNavigate('advisories')}>Review source <ArrowRight size={14} /></button></section>}
        {preferences.dashboard.alerts && <section className="surface alerts-preview"><div className="panel-heading"><div><p className="eyebrow">STAFF & FAMILY UPDATES</p><h2>Recent alerts</h2></div><button className="icon-button" onClick={onShowAlerts} aria-label="Open alerts"><Bell size={16} /></button></div><div className="recent-alert-list">{alerts.slice(0, 2).map((alert) => <div className="recent-alert" key={alert.id}><i className={`alert-dot ${statusClass(alert.status)}`} /><div><strong>{alert.title}</strong><span>{alert.detail}</span></div><time>{alert.time}</time></div>)}{alerts.length === 0 && <div className="empty-inline">No alerts generated in this session.</div>}</div><button className="text-button" onClick={() => onNavigate('advisories')}>Configure demo alert channels <ArrowRight size={13} /></button></section>}
      </div>}
    </>
  );
}

function Planner({ activities, decisions, isLive, hasForecast, snapshot, clockFormat, onOpenDecision, onEdit, onDelete, onAdd, onReset }: {
  activities: Activity[]; decisions: Decision[]; isLive: boolean; hasForecast: boolean; snapshot: TinyFishSnapshot | null; clockFormat: ClockFormat; onOpenDecision: (decision: Decision) => void; onEdit: (activity: Activity) => void; onDelete: (activity: Activity) => void; onAdd: () => void; onReset: () => void;
}) {
  const sorted = activities.slice().sort((a, b) => a.time.localeCompare(b.time));
  return (
    <div className="subpage"><div className="subpage-heading"><div><p className="eyebrow">SCHOOL DAY · {hasForecast ? 'SAFAR LIVE FORECAST' : isLive ? 'LATEST CPCB AQI SNAPSHOT' : 'SIMULATED FORECAST'}</p><h1>Activity planner</h1><p>Each activity is evaluated against its time slot, age group, venue and school thresholds.</p></div><button className="button button--primary" onClick={onAdd}><Plus size={16} /> Add activity</button></div>
      <section className={`surface planner-banner ${isLive ? 'planner-banner--live' : ''}`}><div className="planner-banner-icon"><Clock3 size={18} /></div><div><strong>{hasForecast ? 'SAFAR published Delhi forecast' : isLive ? `CPCB ${snapshot?.currentAqi?.city ?? 'city'} AQI ${snapshot?.currentAqi?.aqi ?? '—'} · ${snapshot?.currentAqi?.observationLabel ?? 'latest bulletin'}` : 'Plan window: 6:30 AM–6:00 PM'}</strong><span>{hasForecast ? `${snapshot?.forecast.points.length ?? 0} source-backed forecast points loaded. Check the source and latest station bulletin before each activity.` : isLive ? 'No verified forward forecast is available. The latest city-level 24-hour reading is held constant for each scheduled activity; recheck conditions before the event.' : 'Forecasts and recommendations shown here use the demo scenario and update when you simulate a refresh.'}</span></div><span className={`demo-pill ${isLive ? 'demo-pill--live' : ''}`}>{hasForecast ? 'LIVE FORECAST' : isLive ? 'CURRENT INPUT' : 'NOT LIVE DATA'}</span></section>
      <section className="surface planner-table"><div className="planner-table-head"><div><p className="eyebrow">YOUR SCHOOL’S DAY</p><h2>{sorted.length} activities · {sorted.filter((activity) => decisions.find((decision) => decision.activityId === activity.id)?.status === 'NO-GO').length} require a no-go plan</h2></div><button className="button button--quiet" onClick={onReset}><RefreshCw size={14} /> Reset demo schedule</button></div>{sorted.length ? <div className="planner-rows">{sorted.map((activity, index) => { const decision = decisions.find((item) => item.activityId === activity.id); if (!decision) return null; return <div className="planner-row" key={activity.id}><div className="planner-index">{String(index + 1).padStart(2, '0')}</div><div className="planner-row-time"><Clock3 size={14} />{formatClock(activity.time, clockFormat)}</div><div className="planner-row-title"><strong>{activity.title}</strong><span>{activity.kind} · {activity.group} · {activity.venue}</span></div><div className="planner-aqi"><span>{hasForecast ? 'SAFAR FORECAST' : isLive ? 'LATEST AQI' : 'FORECAST'}</span><strong>{decision.aqi}<small> AQI</small></strong></div><div className="planner-row-recommendation"><StatusTag status={decision.status} compact /><span>{decision.action}</span></div><div className="planner-row-actions"><button aria-label="Edit activity" onClick={() => onEdit(activity)}><MoreHorizontal size={17} /></button><button aria-label="View decision evidence" onClick={() => onOpenDecision(decision)}><ExternalLink size={15} /></button><button aria-label="Delete activity" onClick={() => onDelete(activity)}><X size={15} /></button></div></div>; })}</div> : <div className="empty-block empty-block--large"><ActivityIcon size={28} /><strong>Your school day is clear.</strong><span>Schedule a school activity to see a recommendation.</span><button className="button button--primary" onClick={onAdd}><Plus size={15} /> Add activity</button></div>}</section>
      <div className="planner-footnote"><Info size={14} /><span>Decisions are guidance for demonstration only and are not medical advice or official school closure instructions.</span></div>
    </div>
  );
}

function DecisionLog({ log, search, setSearch, filter, setFilter, clockFormat, onOpen, onExport }: {
  log: Decision[]; search: string; setSearch: (value: string) => void; filter: string; setFilter: (value: string) => void; clockFormat: ClockFormat; onOpen: (decision: Decision) => void; onExport: () => void;
}) {
  const filtered = log.filter((item) => {
    const query = search.toLowerCase().trim();
    const match = !query || [item.title, item.kind, item.group, item.action, ...item.reasons].join(' ').toLowerCase().includes(query);
    return match && (filter === 'All decisions' || item.status === filter);
  });
  return (
    <div className="subpage"><div className="subpage-heading"><div><p className="eyebrow">ACCOUNTABILITY · LOCAL SESSION HISTORY</p><h1>Decision log</h1><p>Search the recorded recommendation, data input and reason behind each call.</p></div><button className="button button--outline" onClick={onExport}><Download size={15} /> Export CSV</button></div>
      <div className="surface log-toolbar"><div className="search-field"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search activities, reasons, groups…" /></div><label className="filter-select"><Filter size={14} /><select value={filter} onChange={(event) => setFilter(event.target.value)}><option>All decisions</option><option>GO</option><option>MODIFY</option><option>NO-GO</option></select><ChevronDown size={14} /></label><span className="log-total">{filtered.length} {filtered.length === 1 ? 'record' : 'records'}</span></div>
      <section className="surface log-table"><div className="log-table-head"><span>ACTIVITY / TIME</span><span>AQI BASIS & SOURCE</span><span>RECOMMENDATION</span><span>RECORDED</span></div>{filtered.length ? filtered.map((decision) => <button className="log-row" key={decision.id} onClick={() => onOpen(decision)}><div className="log-title"><span className={`log-activity-icon ${statusClass(decision.status)}`}>{decision.status === 'GO' ? <ShieldCheck size={15} /> : decision.status === 'MODIFY' ? <SlidersHorizontal size={15} /> : <ShieldAlert size={15} />}</span><span><strong>{decision.title}</strong><small>{formatClock(decision.time, clockFormat)} · {decision.group}</small></span></div><div className="log-aqi"><strong>{decision.aqi} <small>AQI</small></strong><span>{decision.band} · {decision.dataBasis === 'demo-forecast' ? 'Demo forecast scenario' : decision.source}</span></div><div className="log-recommendation"><StatusTag status={decision.status} compact /><span>{decision.statusChange || decision.action}</span></div><div className="log-date"><span>{new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', timeZone: 'Asia/Kolkata' }).format(new Date(decision.recordedAt))}</span><small>{new Intl.DateTimeFormat('en-IN', { hour: '2-digit', minute: '2-digit', hourCycle: clockFormat === '24h' ? 'h23' : 'h12', timeZone: 'Asia/Kolkata' }).format(new Date(decision.recordedAt))} IST</small><ChevronRight size={15} /></div></button>) : <div className="empty-block empty-block--large"><Search size={24} /><strong>No matching decisions.</strong><span>Try a different search or result filter.</span></div>}</section>
      <div className="planner-footnote"><Info size={14} /><span>History is kept in this browser’s local storage and is not synced to a school server.</span></div>
    </div>
  );
}

function AdvisoryCenter({ profile, alerts, snapshot, snapshotStale, liveError, liveLoading, onSyncLive, setAdvisory, addAlert, onRead, onReadAll, onSendTest }: {
  profile: SchoolProfile; alerts: AppAlert[]; snapshot: TinyFishSnapshot | null; snapshotStale: boolean; liveError: string; liveLoading: boolean; onSyncLive: () => void; setAdvisory: (active: boolean) => void; addAlert: (title: string, detail: string, status?: DecisionStatus | 'INFO') => void; onRead: (id: string) => void; onReadAll: () => void; onSendTest: () => void;
}) {
  const [channels, setChannels] = useState(() => readStored<{ staff: boolean; parents: boolean }>(STORE.targets, { staff: true, parents: true }));
  const setChannel = (key: 'staff' | 'parents', value: boolean) => {
    const updated = { ...channels, [key]: value };
    setChannels(updated);
    localStorage.setItem(STORE.targets, JSON.stringify(updated));
  };
  const toggleAdvisory = () => {
    const next = !profile.advisoryActive;
    setAdvisory(next);
    addAlert(next ? 'Demo advisory override enabled' : 'Demo advisory override cleared', next ? 'Illustrative competition pause is now included in activity decisions. This local rule is separate from the live CAQM source card.' : 'Activity decisions returned to the AQI threshold rules. The CAQM source card remains informational and is not a school-specific order.', 'INFO');
  };
  return (
    <div className="subpage"><div className="subpage-heading"><div><p className="eyebrow">OFFICIAL SOURCES · ALERT ROUTING</p><h1>Advisories & alerts</h1><p>Review fetched official context separately from the school’s own demo decision rule.</p></div><span className={`demo-pill demo-pill--large ${snapshot && !snapshotStale ? 'demo-pill--live' : ''}`}><Radio size={12} /> {liveLoading ? 'SYNCING' : snapshotStale ? 'LAST SNAPSHOT · STALE' : snapshot ? 'TINYFISH SNAPSHOT' : 'SOURCE NOT CHECKED'}</span></div>
      <section className="surface official-advisory-card"><div className={`official-advisory-beacon ${snapshot?.advisory.status === 'active' && !snapshotStale ? 'official-advisory-beacon--active' : ''}`}><ShieldAlert size={19} /></div><div className="official-advisory-copy"><p className="eyebrow">OFFICIAL CAQM / GRAP SOURCE · {snapshotStale ? 'LAST CHECK FAILED · STATUS STALE' : snapshot?.advisory.status === 'active' ? 'SOURCE LISTING SAYS ACTIVE' : snapshot?.advisory.status === 'order-found' ? 'ORDER FOUND · FORCE UNVERIFIED' : snapshot?.advisory.status === 'unavailable' ? 'STATUS UNAVAILABLE' : 'NOT YET VERIFIED'}</p><h2>{snapshot?.advisory.stage ? `${snapshotStale ? 'Last known ' : ''}${snapshot.advisory.stage} · ${snapshot?.advisory.status === 'active' ? 'listed active' : 'listed, current force unverified'}${snapshotStale ? ' · recheck required' : ''}` : 'No current stage could be verified yet.'}</h2><p>{snapshotStale ? `A live refresh failed: ${liveError} The following is the last successful snapshot only — not confirmation of current status. ${snapshot?.advisory.evidence ?? ''}` : snapshot?.advisory.evidence || snapshot?.warnings.find((warning) => /caqm|grap/i.test(warning)) || liveError || 'Use “Sync live sources” to search current CAQM material. The local example switch below is not a government order.'}</p><small>{snapshotStale ? 'Last successful retrieval' : 'Retrieved'} {formatSourceTime(snapshot?.fetchedAt)}{snapshot?.advisory.effectiveDate ? ` · listed effective date ${snapshot.advisory.effectiveDate}` : ''}</small></div><div className="official-advisory-actions">{(snapshot?.advisory.orderPdfUrl || snapshot?.advisory.sourceUrl) && <a className="button button--outline" href={snapshot.advisory.orderPdfUrl || snapshot.advisory.sourceUrl || '#'} target="_blank" rel="noreferrer">Read official source <ExternalLink size={14} /></a>}{snapshot?.advisory.scheduleUrl && <a className="source-link" href={snapshot.advisory.scheduleUrl} target="_blank" rel="noreferrer">GRAP schedule <ExternalLink size={12} /></a>}<button className="button button--primary" onClick={onSyncLive} disabled={liveLoading}><RefreshCw size={14} className={liveLoading ? 'icon-spin' : ''} />{liveLoading ? 'Syncing…' : 'Sync live sources'}</button></div><div className="official-advisory-caveat"><Info size={14} /><span>A reported regional stage is context only—not an automatic school closure or activity restriction. Verify the original order and the school or competent-authority instruction.</span></div></section>
      <div className="protocol-grid"><section className="surface protocol-card"><div className="protocol-card-head"><div className="protocol-icon protocol-icon--amber"><ShieldAlert size={18} /></div><div><p className="eyebrow">ADVISORY RULE SIMULATOR</p><h2>Outdoor competition guard</h2></div><span className={`rule-state ${profile.advisoryActive ? 'rule-state--on' : ''}`}><i />{profile.advisoryActive ? 'ACTIVE' : 'OFF'}</span></div><div className="advisory-doc"><div className="advisory-doc-top"><span className="doc-mark">DEMO</span><span>Illustrative activity restriction</span></div><h3>When forecast AQI is above the moderate band</h3><p>Pause outdoor competition teams until the next school review. This rule is a demonstration input only; it is <strong>not an issued CAQM/GRAP order.</strong></p><div className="doc-source"><Info size={13} /> Source: editable local demo rule · no official source connected</div></div><div className="protocol-card-foot"><div><strong>Include this override in decisions</strong><span>Competition results above AQI {profile.moderateMax} become NO-GO.</span></div><button className={`toggle-switch ${profile.advisoryActive ? 'toggle-switch--on' : ''}`} onClick={toggleAdvisory} aria-pressed={profile.advisoryActive} aria-label="Toggle demonstration advisory"><i /></button></div></section>
        <section className="surface protocol-card alert-routing-card"><div className="protocol-card-head"><div className="protocol-icon protocol-icon--mint"><Bell size={17} /></div><div><p className="eyebrow">LOCAL ALERT PREVIEW</p><h2>Stakeholder routing</h2></div><span className="demo-pill">SIMULATED</span></div><p className="routing-intro">Decision changes create an in-app notice. Switch the preview recipients to see how the school might route it.</p><label className="channel-toggle"><span className="channel-avatar channel-avatar--staff">S</span><span><strong>School staff</strong><small>Principal · PE coordinator</small></span><input type="checkbox" checked={channels.staff} onChange={(event) => setChannel('staff', event.target.checked)} /><i /></label><label className="channel-toggle"><span className="channel-avatar channel-avatar--family">P</span><span><strong>Parents & guardians</strong><small>Class community · demo only</small></span><input type="checkbox" checked={channels.parents} onChange={(event) => setChannel('parents', event.target.checked)} /><i /></label><div className="routing-notice"><TriangleAlert size={14} /><span>No WhatsApp, SMS or email provider is configured. This demo never sends messages outside this page.</span></div><button className="button button--primary button--full" onClick={onSendTest}><Bell size={15} /> Create a test alert in this demo</button></section></div>
      <section className="surface advisory-history"><div className="panel-heading"><div><p className="eyebrow">LOCAL ALERT HISTORY</p><h2>Recent school notifications</h2></div><button className="text-button" onClick={onReadAll}>Mark all read <Check size={14} /></button></div><div className="advisory-alert-list">{alerts.map((alert) => <div className={`advisory-alert-row ${alert.read ? 'advisory-alert-row--read' : ''}`} key={alert.id}><div className={`alert-row-icon ${statusClass(alert.status)}`}>{alert.status === 'NO-GO' ? <TriangleAlert size={15} /> : alert.status === 'MODIFY' ? <SlidersHorizontal size={15} /> : <Info size={15} />}</div><div className="alert-row-copy"><strong>{alert.title}</strong><p>{alert.detail}</p></div><span className={`status-tag ${alert.status === 'INFO' ? 'status-info' : statusClass(alert.status)}`}>{alert.status}</span><time>{alert.time}</time>{!alert.read && <button className="mark-read" onClick={() => onRead(alert.id)} aria-label="Mark alert reviewed"><Check size={14} /></button>}</div>)}{alerts.length === 0 && <div className="empty-inline">No demo alerts yet.</div>}</div></section>
      <div className="planner-footnote"><Info size={14} /><span>TinyFish retrieves public source material only. This prototype does not infer school closures from a regional stage, and it does not send external parent/staff messages.</span></div>
    </div>
  );
}

function SchoolSettings({ profile, aqi, isLive, snapshot, liveLoading, onSyncLive, onSaveProfile, onApplyAqi, onReset }: { profile: SchoolProfile; aqi: number; isLive: boolean; snapshot: TinyFishSnapshot | null; liveLoading: boolean; onSyncLive: () => void; onSaveProfile: (profile: SchoolProfile) => void; onApplyAqi: (aqi: number) => void; onReset: () => void }) {
  const [draftProfile, setDraftProfile] = useState(profile);
  const [draftAqi, setDraftAqi] = useState(aqi);
  useEffect(() => { setDraftProfile(profile); }, [profile]);
  useEffect(() => { setDraftAqi(aqi); }, [aqi]);
  const updateThreshold = (key: 'safeMax' | 'moderateMax' | 'highMax', raw: string) => {
    const value = Math.max(25, Math.min(450, Number(raw) || 0));
    let next = { ...draftProfile, [key]: value };
    if (key === 'safeMax') next = { ...next, safeMax: Math.min(value, draftProfile.moderateMax - 1) };
    if (key === 'moderateMax') next = { ...next, moderateMax: Math.max(draftProfile.safeMax + 1, Math.min(value, draftProfile.highMax - 1)) };
    if (key === 'highMax') next = { ...next, highMax: Math.max(draftProfile.moderateMax + 1, value) };
    setDraftProfile(next);
  };
  const liveDataNote = isLive
    ? `${snapshot?.currentAqi?.sourceName ?? 'CPCB'} · ${snapshot?.currentAqi?.city ?? profile.district} city aggregate · ${snapshot?.currentAqi?.observationLabel ?? 'latest bulletin'} · retrieved ${formatSourceTime(snapshot?.fetchedAt)}. It is not a nearest-station or campus reading. ${snapshot?.forecast.status === 'available' ? 'A SAFAR forecast is available separately.' : 'No verified forward forecast is available; live decisions use the current city value consistently.'}`
    : liveLoading
      ? 'TinyFish is checking CPCB, SAFAR and CAQM. The demo scenario stays active until a fresh CPCB city row is verified.'
      : snapshot?.currentAqi?.freshness === 'fresh'
        ? `A fresh CPCB city snapshot is available from ${snapshot.currentAqi.observationLabel}, but DEMO mode is selected; sync live sources to use it in decisions.`
        : snapshot?.warnings.length
          ? `${snapshot.warnings.join(' ')} Demo AQI remains active; no missing source data is inferred.`
          : snapshot
            ? 'The latest public-source snapshot is shown in the advisory view; the CPCB row was not fresh enough to drive decisions. Demo AQI remains active.'
            : 'Current and forecast demo values are local sample data. Sync TinyFish to check official public sources.';
  return (
    <div className="subpage"><div className="subpage-heading"><div><p className="eyebrow">SCHOOL CONTEXT · DECISION RULES</p><h1>School settings</h1><p>Set school context and prototype thresholds; use a live input only when its CPCB source is verified.</p></div><div className="settings-heading-actions"><button className="button button--quiet" onClick={onReset}><RefreshCw size={14} /> Restore demo defaults</button><button className="button button--primary" onClick={() => onSaveProfile(draftProfile)}><Check size={14} /> Save school profile</button></div></div>
      <div className="settings-grid"><section className="surface settings-card"><div className="settings-card-title"><div className="settings-card-icon"><Home size={18} /></div><div><h2>School profile</h2><p>Used to contextualize the schedule and city-level source query.</p></div></div><label className="field-label">School name<input value={draftProfile.schoolName} onChange={(event) => setDraftProfile({ ...draftProfile, schoolName: event.target.value })} /></label><div className="form-pair"><label className="field-label">District / area<input value={draftProfile.district} onChange={(event) => setDraftProfile({ ...draftProfile, district: event.target.value })} /></label><label className="field-label">Reference station (context only)<input value={draftProfile.station} onChange={(event) => setDraftProfile({ ...draftProfile, station: event.target.value })} /></label></div><div className="profile-note"><MapPin size={15} /><span>TinyFish resolves this field to a Delhi-NCR city average. It does not infer the nearest monitoring station or a campus micro-location.</span></div></section>
        <section className="surface settings-card"><div className="settings-card-title"><div className="settings-card-icon settings-card-icon--amber"><SlidersHorizontal size={18} /></div><div><h2>Activity thresholds</h2><p>Adjust the default AQI bands for school recommendations.</p></div></div><div className="threshold-list"><label className="threshold-row"><span className="threshold-swatch threshold-swatch--mint" /><span><strong>Low exposure</strong><small>GO · all activity groups</small></span><span className="threshold-input-wrap">≤<input type="number" min={25} max={449} value={draftProfile.safeMax} onChange={(event) => updateThreshold('safeMax', event.target.value)} /></span></label><label className="threshold-row"><span className="threshold-swatch threshold-swatch--yellow" /><span><strong>Elevated</strong><small>Shorter for primary students</small></span><span className="threshold-input-wrap">≤<input type="number" min={26} max={449} value={draftProfile.moderateMax} onChange={(event) => updateThreshold('moderateMax', event.target.value)} /></span></label><label className="threshold-row"><span className="threshold-swatch threshold-swatch--amber" /><span><strong>High</strong><small>Modify; competitions deferred</small></span><span className="threshold-input-wrap">≤<input type="number" min={27} max={450} value={draftProfile.highMax} onChange={(event) => updateThreshold('highMax', event.target.value)} /></span></label><label className="threshold-row threshold-row--critical"><span className="threshold-swatch threshold-swatch--rose" /><span><strong>Very high</strong><small>NO-GO · all outdoor exertion</small></span><span className="threshold-locked">{draftProfile.highMax + 1}+<ShieldCheck size={13} /></span></label></div><div className="rule-disclaimer"><Info size={14} /><span>Configurable demonstration defaults. Follow official school and government guidance.</span></div></section></div>
      <section className="surface scenario-card"><div><p className="eyebrow">DEMO CONTROL · NOT A SENSOR READING</p><h2>Adjust the AQI scenario</h2><p>Move the value to explore how each group’s recommendations and risk visualization change.</p></div><div className="scenario-control"><div className="scenario-value"><strong>{draftAqi}</strong><span>AQI</span><span className="scenario-category">{aqiName(draftAqi)}</span></div><input type="range" min="35" max="500" step="1" value={draftAqi} onChange={(event) => setDraftAqi(Number(event.target.value))} aria-label="Set demo AQI scenario" /><div className="range-ticks"><span>35 · clean</span><span>200 · elevated</span><span>500 · severe</span></div><button className="button button--outline scenario-apply" disabled={draftAqi === aqi} onClick={() => onApplyAqi(draftAqi)}><Check size={13} /> Apply scenario</button></div></section>
      <section className={`settings-data-note ${isLive ? 'settings-data-note--live' : ''}`}><div className="data-note-icon"><Info size={17} /></div><div><strong>{isLive ? 'Live source · current AQI' : 'Demo AQI active · live source status shown below'}</strong><p>{liveDataNote} Profile and audit history are saved to this browser; an outbound messaging provider is not connected.</p></div><button className="button button--outline" onClick={onSyncLive} disabled={liveLoading}><RefreshCw size={14} className={liveLoading ? 'icon-spin' : ''} />{liveLoading ? 'Syncing…' : 'Sync live sources'}</button></section>
    </div>
  );
}

function App() {
  const [preferences, setPreferences] = useState<PlatformPreferences>(() => loadPlatformPreferences());
  const [view, setView] = useState<ViewId>(() => preferences.startPage);
  const [aqi, setAqiState] = useState(() => readStored(STORE.aqi, DEFAULT_AQI));
  const [profile, setProfileState] = useState<SchoolProfile>(() => readStored(STORE.profile, DEFAULT_PROFILE));
  const [activities, setActivitiesState] = useState<Activity[]>(() => readStored(STORE.activities, DEFAULT_ACTIVITIES));
  const [log, setLog] = useState<Decision[]>(() => {
    const saved = readStored<Decision[]>(STORE.log, []);
    const savedIds = new Set(saved.map((item) => item.activityId));
    const additions = DEFAULT_ACTIVITIES.filter((activity) => !savedIds.has(activity.id));
    return saved.length ? [...buildInitialLog(additions, DEFAULT_AQI, DEFAULT_PROFILE), ...saved] : buildInitialLog(DEFAULT_ACTIVITIES, DEFAULT_AQI, DEFAULT_PROFILE);
  });
  const [alerts, setAlerts] = useState<AppAlert[]>(() => readStored(STORE.alerts, DEFAULT_ALERTS));
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedDecision, setSelectedDecision] = useState<Decision | null>(null);
  const [editor, setEditor] = useState<Activity | 'new' | null>(null);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All decisions');
  const [toast, setToast] = useState('');
  const [mobileNav, setMobileNav] = useState(false);
  const [dataMode, setDataMode] = useState<'demo' | 'live'>('demo');
  const [liveSnapshot, setLiveSnapshot] = useState<TinyFishSnapshot | null>(null);
  const [snapshotStale, setSnapshotStale] = useState(false);
  const [liveLoading, setLiveLoading] = useState(false);
  const [liveError, setLiveError] = useState('');
  const initialSyncStarted = useRef(false);

  const isLiveMode = dataMode === 'live' && liveSnapshot?.currentAqi?.freshness === 'fresh';
  const activeAqi = isLiveMode && liveSnapshot?.currentAqi ? liveSnapshot.currentAqi.aqi : aqi;
  const hasVerifiedForecast = Boolean(isLiveMode && liveSnapshot?.forecast.status === 'available' && liveSnapshot.forecast.points.length > 1);
  const decisionEvidence = useMemo<DecisionEvidence>(() => {
    if (!isLiveMode || !liveSnapshot?.currentAqi) return { dataBasis: 'demo-forecast', source: 'BreatheSafe synthetic demo forecast · not a source observation' };
    if (hasVerifiedForecast && liveSnapshot.forecast.sourceUrl) return { dataBasis: 'live-forecast', source: 'SAFAR Delhi forecast', sourceUrl: liveSnapshot.forecast.sourceUrl, observationLabel: liveSnapshot.forecast.message, sourceCheckedAt: liveSnapshot.forecast.checkedAt, dataCoverage: `${liveSnapshot.forecast.points.length} parsed forecast points` };
    return { dataBasis: 'live-current', source: `${liveSnapshot.currentAqi.sourceName} · ${liveSnapshot.currentAqi.city} city AQI`, sourceUrl: liveSnapshot.currentAqi.sourceUrl, observationLabel: liveSnapshot.currentAqi.observationLabel, sourceCheckedAt: liveSnapshot.fetchedAt, dataCoverage: `${liveSnapshot.currentAqi.coverage} · ${liveSnapshot.currentAqi.pollutant}` };
  }, [hasVerifiedForecast, isLiveMode, liveSnapshot]);
  const points = useMemo(() => {
    if (hasVerifiedForecast && liveSnapshot) return liveSnapshot.forecast.points;
    if (isLiveMode && liveSnapshot?.currentAqi) return forecastForAqi(liveSnapshot.currentAqi.aqi).map((point) => ({ ...point, aqi: liveSnapshot.currentAqi!.aqi, label: `${liveSnapshot.currentAqi!.observationLabel} · latest city AQI held flat, not a forecast` }));
    return forecastForAqi(aqi);
  }, [aqi, hasVerifiedForecast, isLiveMode, liveSnapshot]);
  const decisions = useMemo(() => activities.map((activity) => evaluateActivity(activity, getActivityAqi(activity, points, activeAqi), profile, decisionEvidence)), [activities, activeAqi, decisionEvidence, points, profile]);
  const unreadCount = alerts.filter((alert) => !alert.read).length;

  useEffect(() => { localStorage.setItem(STORE.aqi, JSON.stringify(aqi)); }, [aqi]);
  useEffect(() => { localStorage.setItem(STORE.profile, JSON.stringify(profile)); }, [profile]);
  useEffect(() => { localStorage.setItem(STORE.activities, JSON.stringify(activities)); }, [activities]);
  useEffect(() => { localStorage.setItem(STORE.log, JSON.stringify(log.slice(0, 160))); }, [log]);
  useEffect(() => { localStorage.setItem(STORE.alerts, JSON.stringify(alerts.slice(0, 40))); }, [alerts]);
  useEffect(() => { try { localStorage.setItem(PREFERENCES_KEY, JSON.stringify(preferences)); } catch { setToast('Could not save preferences in this browser'); } }, [preferences]);
  useEffect(() => { if (!toast) return undefined; const timer = window.setTimeout(() => setToast(''), 3200); return () => window.clearTimeout(timer); }, [toast]);

  const pushAlert = (title: string, detail: string, status: DecisionStatus | 'INFO' = 'INFO') => {
    const alert: AppAlert = { id: `notice-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, title, detail, time: currentTime(), status, read: false };
    setAlerts((current) => [alert, ...current].slice(0, 40));
  };
  const appendLog = (entry: Decision) => setLog((current) => [entry, ...current].slice(0, 160));

  const syncLiveSources = async () => {
    if (liveLoading) return;
    setLiveLoading(true);
    setLiveError('');
    try {
      const snapshot = await refreshTinyFishSources(profile.district || 'Delhi-NCR');
      setLiveSnapshot(snapshot);
      setSnapshotStale(false);
      const reading = snapshot.currentAqi;
      if (!reading || reading.freshness !== 'fresh') {
        setDataMode('demo');
        const message = snapshot.warnings.slice(0, 2).join(' ') || (reading ? `CPCB bulletin is ${reading.freshness}; a fresh row is required.` : 'No fresh CPCB city row could be verified.');
        setLiveError(message);
        if (snapshot.advisory.status === 'active') pushAlert('CAQM source reports an active regional stage', `${snapshot.advisory.stage ?? 'An active stage'} is listed in the fetched source. Review the official order; this app does not infer school closure or sports restrictions.`, 'INFO');
        setToast('Live sources checked · demo AQI retained because CPCB was not fresh');
        return;
      }

      const hasForecast = snapshot.forecast.status === 'available' && snapshot.forecast.points.length > 1;
      const nextPoints = hasForecast ? snapshot.forecast.points : forecastForAqi(reading.aqi).map((point) => ({ ...point, aqi: reading.aqi, label: `${reading.observationLabel} · latest city AQI held flat, not a forecast` }));
      const nextEvidence: DecisionEvidence = hasForecast && snapshot.forecast.sourceUrl
        ? { dataBasis: 'live-forecast', source: 'SAFAR Delhi forecast', sourceUrl: snapshot.forecast.sourceUrl, observationLabel: snapshot.forecast.points[0]?.label || snapshot.forecast.message, sourceCheckedAt: snapshot.forecast.checkedAt, dataCoverage: `${snapshot.forecast.points.length} parsed forecast points` }
        : { dataBasis: 'live-current', source: `${reading.sourceName} · ${reading.city} city AQI`, sourceUrl: reading.sourceUrl, observationLabel: reading.observationLabel, sourceCheckedAt: snapshot.fetchedAt, dataCoverage: `${reading.coverage} · ${reading.pollutant}` };
      const nextDecisions = activities.map((activity) => evaluateActivity(activity, getActivityAqi(activity, nextPoints, reading.aqi), profile, nextEvidence));
      const changes = nextDecisions.filter((decision) => decisions.find((old) => old.activityId === decision.activityId)?.status !== decision.status);
      const caqmChanged = liveSnapshot?.advisory.status !== snapshot.advisory.status || liveSnapshot?.advisory.stage !== snapshot.advisory.stage;
      const currentWorsened = liveSnapshot?.currentAqi?.freshness === 'fresh' && reading.aqi >= liveSnapshot.currentAqi.aqi + 10;
      const forecastWorsened = hasForecast && liveSnapshot?.forecast.status === 'available' && nextPoints.some((point) => {
        const previous = liveSnapshot.forecast.points.find((old) => old.time === point.time);
        return previous ? point.aqi >= previous.aqi + 15 : false;
      });
      setDataMode('live');
      nextDecisions.forEach((decision) => appendLog({ ...decision, id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, statusChange: changes.some((item) => item.activityId === decision.activityId) ? `Status changed to ${decision.status} after live source refresh` : `Live source snapshot refreshed · ${decision.observationLabel ?? reading.observationLabel}` }));
      if (changes.length) {
        const summary = changes.map((decision) => `${decision.title}: ${decision.status}`).join(' · ');
        const advisoryNote = caqmChanged ? ` CAQM lookup: ${snapshot.advisory.stage ?? snapshot.advisory.status}; review the official source, not just this regional signal.` : '';
        pushAlert('Live air data changed activity recommendations', `${summary}. CPCB city AQI ${reading.aqi}; ${hasForecast ? 'SAFAR forecast applied' : 'no verified forecast; CPCB AQI held constant'}.${advisoryNote} Review the source and schedule.`, decisionAlertStatus(changes));
      } else if (caqmChanged) {
        pushAlert('CAQM source status changed', `${snapshot.advisory.stage ? `${snapshot.advisory.stage} · ` : ''}${snapshot.advisory.status}. Open the official order and confirm the school-specific instruction; a regional stage is not an automatic closure rule.`, 'INFO');
      } else if (currentWorsened || forecastWorsened) {
        pushAlert('Live air-quality outlook worsened', `${currentWorsened ? `CPCB city AQI rose from ${liveSnapshot?.currentAqi?.aqi} to ${reading.aqi}.` : ''} ${forecastWorsened ? 'One or more SAFAR forecast points increased by at least 15 AQI.' : ''} No recommendation status changed yet; review the evidence and plan.`, 'INFO');
      } else {
        pushAlert(`Live sources refreshed for ${reading.city}`, `CPCB AQI ${reading.aqi} · ${reading.category} · observed ${reading.observationLabel}. ${hasForecast ? 'A parsed SAFAR forecast is available.' : 'A verified forward forecast is unavailable.'}`, 'INFO');
      }
      setToast(`CPCB AQI ${reading.aqi} verified · ${hasForecast ? 'SAFAR forecast loaded' : 'no forecast inferred'}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'TinyFish source refresh failed.';
      setLiveError(message);
      setSnapshotStale(Boolean(liveSnapshot));
      setDataMode('demo');
      pushAlert('TinyFish refresh unavailable', `${message} Demo AQI remains active; no live reading was substituted.`, 'INFO');
      setToast('Live sync unavailable · demo data retained');
    } finally {
      setLiveLoading(false);
    }
  };

  const applyAqiScenario = (rawAqi: number, reason: string) => {
    const nextAqi = Math.max(35, Math.min(500, rawAqi));
    if (nextAqi === aqi) return;
    const nextPoints = forecastForAqi(nextAqi);
    const demoEvidence: DecisionEvidence = { dataBasis: 'demo-forecast', source: 'BreatheSafe synthetic demo forecast · not a source observation' };
    const nextDecisions = activities.map((activity) => evaluateActivity(activity, getActivityAqi(activity, nextPoints, nextAqi), profile, demoEvidence));
    const changes = nextDecisions.filter((decision) => decisions.find((old) => old.activityId === decision.activityId)?.status !== decision.status);
    setAqiState(nextAqi);
    setDataMode('demo');
    nextDecisions.forEach((decision) => appendLog({ ...decision, id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, statusChange: changes.some((item) => item.activityId === decision.activityId) ? `Status changed to ${decision.status} after ${reason}` : `Recommendation recalculated after ${reason}` }));
    if (changes.length) {
      const summary = changes.map((decision) => `${decision.title}: ${decision.status}`).join(' · ');
      pushAlert(`Activity recommendations changed after ${reason}`, `${summary}. Review the updated schedule before communicating a decision.`, decisionAlertStatus(changes));
      setToast(`${changes.length} activity ${changes.length === 1 ? 'decision' : 'decisions'} changed · review the schedule`);
    } else if (reason === 'simulated forecast update') {
      pushAlert('Demo forecast refreshed', `Illustrative AQI changed to ${nextAqi}. No activity status changed.`, 'INFO');
      setToast(`Demo scenario updated to AQI ${nextAqi}`);
    } else {
      setToast(`Demo AQI scenario applied · AQI ${nextAqi}`);
    }
  };

  const applyProfileUpdate = (nextProfile: SchoolProfile, reason: string) => {
    if (JSON.stringify(nextProfile) === JSON.stringify(profile)) {
      setToast('No school profile changes to save');
      return;
    }
    const nextDecisions = activities.map((activity) => evaluateActivity(activity, getActivityAqi(activity, points, activeAqi), nextProfile, decisionEvidence));
    const changes = nextDecisions.filter((decision) => decisions.find((old) => old.activityId === decision.activityId)?.status !== decision.status);
    setProfileState(nextProfile);
    nextDecisions.forEach((decision) => appendLog({ ...decision, id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, statusChange: changes.some((item) => item.activityId === decision.activityId) ? `Status changed to ${decision.status} after ${reason}` : `Recommendation re-evaluated after ${reason}` }));
    if (changes.length) {
      const summary = changes.map((decision) => `${decision.title}: ${decision.status}`).join(' · ');
      pushAlert(`Activity recommendations changed after ${reason}`, `${summary}. Review the updated schedule.`, decisionAlertStatus(changes));
      setToast(`${changes.length} recommendation${changes.length === 1 ? '' : 's'} changed after profile update`);
    } else {
      setToast('School profile saved · no activity status changed');
    }
  };

  const simulateUpdate = () => {
    const variations = [-54, -37, -24, 18, 33, 47];
    const nextAqi = Math.max(35, Math.min(500, aqi + variations[Math.floor(Math.random() * variations.length)]));
    applyAqiScenario(nextAqi, 'simulated forecast update');
  };

  const saveActivity = (activity: Activity) => {
    const exists = activities.some((item) => item.id === activity.id);
    const next = exists ? activities.map((item) => item.id === activity.id ? activity : item) : [...activities, activity];
    setActivitiesState(next);
    const point = getActivityAqi(activity, points, activeAqi);
    const decision = evaluateActivity(activity, point, profile, decisionEvidence);
    appendLog({ ...decision, id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, statusChange: exists ? 'Activity details edited; recommendation recalculated' : 'Activity added to the school schedule' });
    pushAlert(exists ? 'Activity updated' : 'New activity decision created', `${activity.title}: ${decision.status} at ${decision.dataBasis === 'live-current' ? 'latest CPCB AQI' : 'AQI input'} ${point}. Local in-app notice; no external message was sent.`, decision.status);
    setEditor(null);
    setToast(exists ? 'Activity updated · recommendation recalculated' : 'Activity added · decision recorded');
  };

  const deleteActivity = (activity: Activity) => {
    const previousDecision = decisions.find((decision) => decision.activityId === activity.id);
    if (previousDecision) appendLog({ ...previousDecision, id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, statusChange: 'Activity removed from the upcoming plan; prior recommendation retained' });
    setActivitiesState((current) => current.filter((item) => item.id !== activity.id));
    setToast(`${activity.title} removed from the current plan · history retained`);
  };

  const resetDemo = () => {
    setAqiState(DEFAULT_AQI);
    setDataMode('demo');
    setLiveError('');
    setProfileState(DEFAULT_PROFILE);
    setActivitiesState(DEFAULT_ACTIVITIES);
    setLog(buildInitialLog(DEFAULT_ACTIVITIES, DEFAULT_AQI, DEFAULT_PROFILE));
    setAlerts(DEFAULT_ALERTS);
    setToast('Demo scenario restored to defaults');
  };

  const resetPlatformPreferences = () => {
    setPreferences(DEFAULT_PREFERENCES);
    setToast('Platform preferences restored · school data and history are unchanged');
  };

  useEffect(() => {
    if (initialSyncStarted.current) return;
    initialSyncStarted.current = true;
    if (!preferences.autoSyncOnLaunch) return;
    void syncLiveSources();
  }, []);

  const markAlertRead = (id: string) => setAlerts((current) => current.map((alert) => alert.id === id ? { ...alert, read: true } : alert));
  const markAllRead = () => setAlerts((current) => current.map((alert) => ({ ...alert, read: true })));
  const exportCsv = () => {
    const quote = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;
    const rows = [['Recorded at', 'Activity', 'Type', 'Time', 'Group', 'Venue', 'AQI', 'Band', 'Data basis', 'Decision', 'Recommended action', 'Reason', 'Source', 'Source URL', 'Observed at', 'Retrieved at', 'Coverage'], ...log.map((item) => [item.recordedAt, item.title, item.kind, item.time, item.group, item.venue, item.aqi, item.band, item.dataBasis ?? 'demo-forecast', item.status, item.statusChange || item.action, item.reasons.join(' | '), item.source, item.sourceUrl ?? '', item.observationLabel ?? '', item.sourceCheckedAt ?? '', item.dataCoverage ?? ''])];
    const csv = rows.map((row) => row.map(quote).join(',')).join('\r\n');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    link.download = 'breathesafe-decision-log-demo.csv';
    link.click();
    URL.revokeObjectURL(link.href);
    setToast('Decision history exported to CSV');
  };

  const renderPage = () => {
    if (view === 'planner') return <Planner activities={activities} decisions={decisions} isLive={isLiveMode} hasForecast={hasVerifiedForecast} snapshot={liveSnapshot} clockFormat={preferences.clockFormat} onOpenDecision={setSelectedDecision} onEdit={setEditor} onDelete={deleteActivity} onAdd={() => setEditor('new')} onReset={resetDemo} />;
    if (view === 'decisions') return <DecisionLog log={log} search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} clockFormat={preferences.clockFormat} onOpen={setSelectedDecision} onExport={exportCsv} />;
    if (view === 'advisories') return <AdvisoryCenter profile={profile} alerts={alerts} snapshot={liveSnapshot} snapshotStale={snapshotStale} liveError={liveError} liveLoading={liveLoading} onSyncLive={() => void syncLiveSources()} setAdvisory={(active) => applyProfileUpdate({ ...profile, advisoryActive: active }, 'demo advisory rule change')} addAlert={pushAlert} onRead={markAlertRead} onReadAll={markAllRead} onSendTest={() => { pushAlert('Test notification created', 'A local preview notice was added for the selected staff/parent routes. No external message was sent.', 'INFO'); setToast('Test alert created in the local demo'); }} />;
    if (view === 'settings') return <SchoolSettings profile={profile} aqi={aqi} isLive={isLiveMode} snapshot={liveSnapshot} liveLoading={liveLoading} onSyncLive={() => void syncLiveSources()} onSaveProfile={(nextProfile) => applyProfileUpdate(nextProfile, 'school profile update')} onApplyAqi={(nextAqi) => applyAqiScenario(nextAqi, 'manual AQI scenario adjustment')} onReset={resetDemo} />;
    if (view === 'customize') return <CustomizationStudio preferences={preferences} onChange={setPreferences} onReset={resetPlatformPreferences} />;
    return <Overview aqi={activeAqi} profile={profile} activities={activities} decisions={decisions} alerts={alerts} points={points} isLive={isLiveMode} hasForecast={hasVerifiedForecast} snapshot={liveSnapshot} snapshotStale={snapshotStale} liveLoading={liveLoading} liveError={liveError} preferences={preferences} onSyncLive={() => void syncLiveSources()} onOpenDecision={setSelectedDecision} onEditActivity={setEditor} onShowAlerts={() => setShowNotifications(true)} onNavigate={setView} onAdd={() => setEditor('new')} />;
  };

  return (
    <div className={`app-frame theme-${preferences.theme} density-${preferences.density} ${preferences.reducedMotion ? 'motion-reduced' : ''} ${preferences.highContrast ? 'access-high-contrast' : ''}`} data-font={preferences.font} data-text-scale={preferences.textScale} style={{ '--brand-accent': preferences.accentColor } as CSSProperties}>
      <aside className={`sidebar ${mobileNav ? 'sidebar--open' : ''}`}>
        <div className="brand-lockup"><div className="brand-mark"><span /><span /><span /></div><div className="brand-wordmark"><strong>BreatheSafe</strong><small>SCHOOLS · AIR DECISIONS</small></div><button className="mobile-close icon-button" onClick={() => setMobileNav(false)} aria-label="Close navigation"><X size={17} /></button></div>
        <div className="sidebar-section-label">OPERATIONS</div><nav className="main-nav">{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${view === id ? 'nav-item--active' : ''}`} onClick={() => { setView(id); setMobileNav(false); }}><Icon size={17} strokeWidth={1.8} /><span>{label}</span>{id === 'advisories' && unreadCount > 0 && <i className="nav-badge">{unreadCount}</i>}</button>)}</nav>
        <div className="sidebar-spacer" />
        <div className={`sidebar-live-card ${isLiveMode ? 'sidebar-live-card--active' : ''}`}><div className="sidebar-live-top"><span className={`live-beacon ${isLiveMode ? 'live-beacon--active' : ''}`} />{liveLoading ? 'TINYFISH CONNECTING' : isLiveMode ? 'LIVE · SOURCE-VERIFIED' : liveSnapshot ? 'PARTIAL · DEMO ACTIVE' : 'DEMO ENVIRONMENT'}</div><strong>{isLiveMode ? `${liveSnapshot?.currentAqi?.city} · AQI ${activeAqi}` : 'Sample AQI retained'}</strong><span>{isLiveMode ? `${liveSnapshot?.currentAqi?.sourceName} · ${liveSnapshot?.currentAqi?.observationLabel}${hasVerifiedForecast ? ' · SAFAR forecast also available' : ' · no forward forecast'}` : liveError || (liveLoading ? 'Checking CPCB, SAFAR and CAQM public sources…' : 'Live values replace the demo only after a fresh CPCB row is verified.')}</span><button onClick={() => void syncLiveSources()} disabled={liveLoading}>{liveLoading ? 'Syncing…' : 'Sync live sources'} <ArrowRight size={13} /></button></div>
        <div className="sidebar-bottom"><div className="profile-avatar">DS</div><div className="profile-name"><strong>{profile.schoolName || 'Demo campus'}</strong><span>{profile.district}</span></div><button className="icon-button icon-button--small" onClick={() => setView('settings')} aria-label="Settings"><Settings2 size={16} /></button></div>
      </aside>

      <main className="main-shell">
        <header className="topbar"><button className="mobile-menu icon-button" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={19} /></button><div className="topbar-crumb"><span className="crumb-dot" /><span>SAFE AIR, SAFER SCHOOL DAYS</span><ChevronRight size={13} /><span className="topbar-page">{navItems.find((item) => item.id === view)?.label}</span></div><div className="topbar-actions"><span className="topbar-date"><span className={`tiny-dot ${isLiveMode ? 'tiny-dot--mint' : 'tiny-dot--amber'}`} />{liveLoading ? 'SYNCING TINYFISH' : isLiveMode ? 'LIVE · CPCB AQI' : 'DEMO INPUT ACTIVE'}</span><button className="topbar-refresh topbar-refresh--live" onClick={() => void syncLiveSources()} disabled={liveLoading}><RefreshCw size={14} className={liveLoading ? 'icon-spin' : ''} /> {liveLoading ? 'Syncing' : 'Live sync'}</button><button className="topbar-refresh topbar-refresh--scenario" onClick={simulateUpdate}><Sparkles size={14} /> Scenario</button><div className="notification-wrap"><button className={`notification-button ${showNotifications ? 'notification-button--active' : ''}`} onClick={() => setShowNotifications((current) => !current)} aria-label="Open alerts"><Bell size={16} />{unreadCount > 0 && <i />}</button>{showNotifications && <NotificationPopover alerts={alerts} onRead={markAlertRead} onClose={() => setShowNotifications(false)} onSeeAll={() => { setShowNotifications(false); setView('advisories'); }} />}</div></div></header>
        <div className={`page-content ${view !== 'overview' ? 'page-content--subpage' : ''}`}>{renderPage()}</div>
        <footer className="app-footer"><span><span className="footer-mark">B</span> BreatheSafe Schools <span className="footer-separator">/</span> decision-support demo</span><span>Built for the bell, not after it <span className="footer-spark">✳</span></span></footer>
      </main>
      {editor && <ActivityEditor initial={editor === 'new' ? undefined : editor} onSave={saveActivity} onClose={() => setEditor(null)} />}
      {selectedDecision && <DecisionModal decision={selectedDecision} clockFormat={preferences.clockFormat} onClose={() => setSelectedDecision(null)} />}
      {toast && <div className="toast-message"><span className="toast-check"><Check size={14} /></span>{toast}</div>}
    </div>
  );
}

export default App;
