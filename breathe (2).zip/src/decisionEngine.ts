import type { Activity, Decision, DecisionEvidence, DecisionStatus, SchoolProfile } from './types';

export function classifyBand(aqi: number, profile: SchoolProfile): string {
  if (aqi <= profile.safeMax) return 'Low exposure';
  if (aqi <= profile.moderateMax) return 'Elevated';
  if (aqi <= profile.highMax) return 'High';
  return 'Very high';
}

export function categoryColor(status: DecisionStatus): string {
  return status === 'GO' ? 'mint' : status === 'MODIFY' ? 'amber' : 'rose';
}

export function evaluateActivity(activity: Activity, aqi: number, profile: SchoolProfile, evidence: DecisionEvidence = {}): Decision {
  const band = classifyBand(aqi, profile);
  const primary = activity.group === 'Primary (6–11)';
  const team = activity.kind === 'Competition' || activity.group === 'Competition team';
  const indoor = activity.venue === 'Indoor';
  const dataBasis = evidence.dataBasis ?? 'demo-forecast';
  const aqiLabel = dataBasis === 'live-current' ? 'Latest reported AQI' : 'Forecast AQI';
  const reasons: string[] = [];
  let status: DecisionStatus = 'GO';
  let action = 'Proceed as planned';

  if (aqi <= profile.safeMax) {
    status = 'GO';
    action = team ? 'Proceed; keep routine monitoring' : 'Proceed as planned';
    reasons.push(`${aqiLabel} ${aqi} is within the school’s low-exposure band (≤${profile.safeMax}).`);
  } else if (aqi <= profile.moderateMax) {
    if (primary && !indoor) {
      status = 'MODIFY';
      action = 'Shorten the session; reduce intensity';
      reasons.push(`AQI ${aqi} is in the ${profile.safeMax + 1}–${profile.moderateMax} band. Use a shorter, lower-intensity session for primary students.`);
    } else {
      status = 'GO';
      action = team ? 'Proceed and monitor the forecast' : 'Proceed; recheck before activity';
      reasons.push(`AQI ${aqi} is in the ${profile.safeMax + 1}–${profile.moderateMax} band; the school profile allows this group to continue with monitoring.`);
    }
  } else if (aqi <= profile.highMax) {
    status = 'MODIFY';
    if (team) {
      action = 'Reschedule competition or move to a cleaner window';
      reasons.push(`Competitive exertion is deferred in the ${profile.moderateMax + 1}–${profile.highMax} band.`);
    } else if (primary) {
      action = indoor ? 'Keep indoors; reduce exertion and duration' : 'Move to the hall or replace with theory';
      reasons.push(`Primary students need a lower-exposure alternative in the ${profile.moderateMax + 1}–${profile.highMax} band.`);
    } else {
      action = indoor ? 'Light indoor activity only' : 'Light activity only; prefer an indoor space';
      reasons.push(`Middle/senior students are limited to light activity in the ${profile.moderateMax + 1}–${profile.highMax} band.`);
    }
  } else {
    status = 'NO-GO';
    action = indoor ? 'Cancel exertion; use a classroom alternative' : 'Stop outdoor exertion; move indoors or cancel';
    reasons.push(`AQI ${aqi} is above the school’s critical threshold (${profile.highMax + 1}+). Outdoor exertion is not recommended.`);
  }

  if (indoor && aqi > profile.safeMax) {
    reasons.push('The activity is marked indoors; this changes the recommended alternative, not the measured outdoor AQI.');
  }
  if (profile.advisoryActive && team && aqi > profile.moderateMax) {
    status = 'NO-GO';
    action = 'Pause outdoor competition; await the next review';
    reasons.push('A demo advisory override is enabled for competitive activity above the moderate band. This is illustrative, not a live CAQM/GRAP order.');
  }
  if (activity.details.trim()) reasons.push(activity.details.trim());
  if (dataBasis === 'live-current') reasons.push('No verified forward forecast is available; the latest CPCB city-bulletin value is used consistently across scheduled activities. Recheck conditions before each event.');

  return {
    id: `decision-${activity.id}`,
    activityId: activity.id,
    title: activity.title,
    kind: activity.kind,
    time: activity.time,
    group: activity.group,
    venue: activity.venue,
    status,
    action,
    reasons,
    aqi,
    band,
    source: evidence.source ?? 'BreatheSafe synthetic demo scenario · not a live source observation',
    sourceUrl: evidence.sourceUrl,
    observationLabel: evidence.observationLabel,
    sourceCheckedAt: evidence.sourceCheckedAt,
    dataCoverage: evidence.dataCoverage,
    dataBasis,
    profileSnapshot: {
      schoolName: profile.schoolName,
      district: profile.district,
      station: profile.station,
      safeMax: profile.safeMax,
      moderateMax: profile.moderateMax,
      highMax: profile.highMax,
      advisoryActive: profile.advisoryActive,
    },
    recordedAt: new Date().toISOString(),
  };
}

export function createLogEntry(activity: Activity, aqi: number, profile: SchoolProfile, statusChange?: string, evidence?: DecisionEvidence): Decision {
  const result = evaluateActivity(activity, aqi, profile, evidence);
  return { ...result, id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, statusChange };
}
