import type { Activity, AppAlert, Decision, ForecastPoint, SchoolProfile } from './types';
import { evaluateActivity } from './decisionEngine';

export const DEFAULT_AQI = 312;
export const DEFAULT_PROFILE: SchoolProfile = {
  schoolName: 'Demo campus',
  district: 'Delhi-NCR',
  station: 'Delhi-NCR reference grid',
  safeMax: 100,
  moderateMax: 200,
  highMax: 300,
  advisoryActive: false,
};

export const DEFAULT_ACTIVITIES: Activity[] = [
  { id: 'assembly', title: 'Morning assembly', kind: 'Assembly', time: '08:00', group: 'Primary (6–11)', venue: 'Outdoor', details: 'School opening gathering' },
  { id: 'pe4', title: 'Class 4 · PE', kind: 'PE', time: '10:30', group: 'Primary (6–11)', venue: 'Outdoor', details: 'Swap with theory if conditions worsen' },
  { id: 'cricket', title: 'Inter-house cricket', kind: 'Competition', time: '13:30', group: 'Competition team', venue: 'Outdoor', details: 'Competitive physical activity' },
  { id: 'football', title: 'Football practice', kind: 'Practice', time: '15:30', group: 'Middle / Senior', venue: 'Outdoor', details: 'Recheck the improving afternoon window' },
];

export const DEFAULT_ALERTS: AppAlert[] = [
  { id: 'alert-1', title: 'Early window flagged', detail: 'Morning assembly and Class 4 PE need a safer alternative in this demo scenario.', time: '06:32', status: 'NO-GO', read: false },
  { id: 'alert-2', title: 'Cleaner afternoon window', detail: 'Later forecast slots are improving. Re-evaluate before football practice.', time: '06:30', status: 'INFO', read: false },
  { id: 'alert-3', title: 'Demo feed active', detail: 'Illustrative sample values remain active until this browser completes a fresh live-source sync.', time: '06:28', status: 'INFO', read: true },
];

export function forecastForAqi(current: number): ForecastPoint[] {
  const profile: SchoolProfile = DEFAULT_PROFILE;
  const shape = [
    { time: '06:30', offset: 0 },
    { time: '08:00', offset: 6 },
    { time: '10:30', offset: -10 },
    { time: '12:00', offset: -38 },
    { time: '13:30', offset: -66 },
    { time: '15:30', offset: -144 },
    { time: '17:00', offset: -170 },
    { time: '18:00', offset: -178 },
  ];
  return shape.map(({ time, offset }) => {
    const aqi = Math.max(36, Math.min(500, Math.round(current + offset)));
    return { time, aqi, label: aqi <= profile.safeMax ? 'Low' : aqi <= profile.moderateMax ? 'Elevated' : aqi <= profile.highMax ? 'High' : 'Very high' };
  });
}

export function buildInitialLog(activities: Activity[], aqi: number, profile: SchoolProfile): Decision[] {
  return activities.map((activity) => {
    const point = forecastForAqi(aqi).find((item) => item.time === activity.time);
    return evaluateActivity(activity, point?.aqi ?? aqi, profile);
  });
}

export function readStored<T>(key: string, fallback: T): T {
  try {
    const stored = localStorage.getItem(key);
    return stored ? (JSON.parse(stored) as T) : fallback;
  } catch {
    return fallback;
  }
}
