import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { ScenePreferences } from './preferences';

interface AtmosphereSceneProps {
  aqi: number;
  compact?: boolean;
  settings: ScenePreferences;
  reducedMotion: boolean;
}

function airColor(aqi: number): THREE.Color {
  if (aqi <= 100) return new THREE.Color('#72e5ba');
  if (aqi <= 200) return new THREE.Color('#e5df83');
  if (aqi <= 300) return new THREE.Color('#ffb46e');
  return new THREE.Color('#ff7775');
}

function makeCampus(): THREE.Group {
  const campus = new THREE.Group();
  const ground = new THREE.Mesh(
    new THREE.BoxGeometry(18, 0.25, 12),
    new THREE.MeshStandardMaterial({ color: '#152a26', roughness: 0.9, metalness: 0.04 }),
  );
  ground.position.y = -0.15;
  campus.add(ground);

  const courtyard = new THREE.Mesh(
    new THREE.PlaneGeometry(7.2, 4.6),
    new THREE.MeshStandardMaterial({ color: '#273c36', roughness: 0.96, metalness: 0 }),
  );
  courtyard.rotation.x = -Math.PI / 2;
  courtyard.position.set(-1.0, 0.008, 1.3);
  campus.add(courtyard);

  const building = new THREE.Group();
  const structure = new THREE.Mesh(
    new THREE.BoxGeometry(7.5, 3.3, 3.6),
    new THREE.MeshStandardMaterial({ color: '#263d38', roughness: 0.7, metalness: 0.08 }),
  );
  structure.position.y = 1.55;
  building.add(structure);

  const roof = new THREE.Mesh(
    new THREE.BoxGeometry(7.95, 0.24, 3.95),
    new THREE.MeshStandardMaterial({ color: '#52746a', roughness: 0.56, metalness: 0.12 }),
  );
  roof.position.y = 3.28;
  building.add(roof);

  const facadeBand = new THREE.Mesh(
    new THREE.BoxGeometry(5.7, 0.16, 0.08),
    new THREE.MeshStandardMaterial({ color: '#8ed6b5', roughness: 0.4, metalness: 0.24, emissive: '#387a5e', emissiveIntensity: 0.15 }),
  );
  facadeBand.position.set(0, 2.78, 1.87);
  building.add(facadeBand);
  const canopy = new THREE.Mesh(new THREE.BoxGeometry(2.45, 0.13, 0.9), new THREE.MeshStandardMaterial({ color: '#8ab89f', roughness: 0.48, metalness: 0.25 }));
  canopy.position.set(0, 1.72, 2.14);
  building.add(canopy);
  for (const x of [-0.94, 0.94]) {
    const support = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.83, 0.08), new THREE.MeshStandardMaterial({ color: '#d4e5d7', roughness: 0.38, metalness: 0.22 }));
    support.position.set(x, 1.28, 2.23);
    building.add(support);
  }
  for (const x of [-1.3, 0, 1.3]) {
    const solarPanel = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.035, 0.72), new THREE.MeshStandardMaterial({ color: '#284e46', roughness: 0.28, metalness: 0.46, emissive: '#1b5442', emissiveIntensity: 0.12 }));
    solarPanel.position.set(x, 3.42, -0.2);
    building.add(solarPanel);
  }

  const wing = new THREE.Mesh(
    new THREE.BoxGeometry(3.6, 2.25, 2.5),
    new THREE.MeshStandardMaterial({ color: '#35524a', roughness: 0.74, metalness: 0.04 }),
  );
  wing.position.set(5.0, 1.03, -1.5);
  building.add(wing);

  const windowMaterial = new THREE.MeshStandardMaterial({
    color: '#b2e9d7',
    emissive: '#57c9a4',
    emissiveIntensity: 0.18,
    metalness: 0.3,
    roughness: 0.24,
  });
  for (let row = 0; row < 2; row += 1) {
    for (let column = 0; column < 6; column += 1) {
      const pane = new THREE.Mesh(new THREE.BoxGeometry(0.57, 0.62, 0.07), windowMaterial);
      pane.position.set(-2.7 + column * 1.08, 1.08 + row * 1.25, 1.84);
      building.add(pane);
    }
  }
  const entrance = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 1.55, 0.1),
    new THREE.MeshStandardMaterial({ color: '#9c7f5e', roughness: 0.64 }),
  );
  entrance.position.set(0, 0.77, 1.85);
  building.add(entrance);
  building.position.set(-1.4, 0, -2.7);
  campus.add(building);

  const track = new THREE.Mesh(
    new THREE.TorusGeometry(3.1, 0.14, 8, 84),
    new THREE.MeshStandardMaterial({ color: '#7b5746', roughness: 0.86, metalness: 0 }),
  );
  track.rotation.x = Math.PI / 2;
  track.scale.set(1.48, 0.7, 1);
  track.position.set(-0.95, 0.03, 1.3);
  campus.add(track);
  for (const radius of [2.72, 3.42]) {
    const laneMark = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.028, 5, 84), new THREE.MeshStandardMaterial({ color: '#c8946c', roughness: 0.76, metalness: 0.02 }));
    laneMark.rotation.x = Math.PI / 2;
    laneMark.scale.set(1.48, 0.7, 1);
    laneMark.position.set(-0.95, 0.034, 1.3);
    campus.add(laneMark);
  }

  const lane = new THREE.Mesh(
    new THREE.PlaneGeometry(3.1, 2.25),
    new THREE.MeshStandardMaterial({ color: '#315b4d', roughness: 0.96, metalness: 0 }),
  );
  lane.rotation.x = -Math.PI / 2;
  lane.position.set(-1, 0.014, 1.3);
  campus.add(lane);

  const path = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 0.025, 7.8),
    new THREE.MeshStandardMaterial({ color: '#6c7463', roughness: 0.95 }),
  );
  path.position.set(4.8, 0.015, 2.3);
  campus.add(path);

  const treeMaterial = new THREE.MeshStandardMaterial({ color: '#356d58', roughness: 0.88 });
  const trunkMaterial = new THREE.MeshStandardMaterial({ color: '#81654e', roughness: 0.96 });
  const treePositions: Array<[number, number]> = [
    [-7.2, -3.7], [-6.1, 4.2], [-4.2, 4.6], [1.4, 4.7], [3.2, -4.4], [6.5, 3.8], [7.2, -3.9],
  ];
  treePositions.forEach(([x, z], index) => {
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.17, 1.1, 7), trunkMaterial);
    trunk.position.set(x, 0.44, z);
    campus.add(trunk);
    const crown = new THREE.Mesh(new THREE.IcosahedronGeometry(index % 2 ? 0.78 : 0.94, 1), treeMaterial);
    crown.position.set(x, 1.45, z);
    crown.scale.set(0.86, 1.15, 0.86);
    campus.add(crown);
  });

  const marker = new THREE.Mesh(
    new THREE.CylinderGeometry(0.02, 0.03, 2.3, 10),
    new THREE.MeshStandardMaterial({ color: '#deefe7', roughness: 0.75 }),
  );
  marker.position.set(-6.2, 1.1, -3.8);
  campus.add(marker);
  const sensorBeacon = new THREE.Mesh(new THREE.SphereGeometry(0.17, 14, 12), new THREE.MeshStandardMaterial({ color: '#ffd19a', emissive: '#ff885f', emissiveIntensity: 1.35, roughness: 0.32 }));
  sensorBeacon.position.set(-6.2, 2.34, -3.8);
  campus.add(sensorBeacon);
  const sensorHalo = new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.018, 5, 36), new THREE.MeshBasicMaterial({ color: '#ffa379', transparent: true, opacity: 0.62 }));
  sensorHalo.position.set(-6.2, 2.34, -3.8);
  sensorHalo.rotation.x = Math.PI / 2;
  campus.add(sensorHalo);
  const pennant = new THREE.Mesh(
    new THREE.PlaneGeometry(1.0, 0.5),
    new THREE.MeshStandardMaterial({ color: '#a8e7d2', side: THREE.DoubleSide, roughness: 0.66 }),
  );
  pennant.position.set(-5.75, 1.78, -3.8);
  pennant.rotation.y = -0.36;
  campus.add(pennant);

  return campus;
}

export default function AtmosphereScene({ aqi, compact = false, settings, reducedMotion: reduceSceneMotion }: AtmosphereSceneProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const colorRef = useRef<THREE.Color>(airColor(aqi));
  const auraOpacityRef = useRef(0.35);
  const colorTargetsRef = useRef<{ particles: THREE.PointsMaterial | null; aura: THREE.MeshBasicMaterial | null; dome: THREE.MeshBasicMaterial | null; haze: THREE.PointLight | null; clouds: THREE.MeshBasicMaterial[]; flows: THREE.MeshBasicMaterial[] }>({ particles: null, aura: null, dome: null, haze: null, clouds: [], flows: [] });

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    let reducedMotion = motionQuery.matches;
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2('#0c1715', 0.025);

    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    camera.position.set(13.5, 10.4, 18);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.16;
    renderer.setClearColor('#0c1715', 0);
    renderer.domElement.setAttribute('aria-label', 'Interactive animated 3D campus atmosphere visualization');
    host.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !reducedMotion;
    controls.dampingFactor = 0.07;
    controls.enablePan = false;
    controls.minDistance = 12;
    controls.maxDistance = 34;
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.target.set(0, 1.1, 0);
    controls.autoRotate = !reducedMotion && !reduceSceneMotion && settings.autoRotate;
    controls.autoRotateSpeed = 0.24;

    scene.add(new THREE.HemisphereLight('#d6fff0', '#20302a', 2.15));
    const keyLight = new THREE.DirectionalLight('#ebf8e7', 3.2);
    keyLight.position.set(8, 12, 6);
    scene.add(keyLight);
    const mintLight = new THREE.PointLight('#65daa9', 18, 21, 2);
    mintLight.position.set(-7, 5, 3);
    scene.add(mintLight);
    const hazeLight = new THREE.PointLight('#ff8e75', 9, 26, 2);
    hazeLight.position.set(5, 7, -7);
    scene.add(hazeLight);

    const campus = makeCampus();
    scene.add(campus);

    const domeMaterial = new THREE.MeshBasicMaterial({ color: colorRef.current, wireframe: true, transparent: true, opacity: 0.05, depthWrite: false, blending: THREE.AdditiveBlending });
    const dome = new THREE.Mesh(new THREE.SphereGeometry(9.5, 18, 9, 0, Math.PI * 2, 0, Math.PI / 2), domeMaterial);
    dome.position.y = 0.02;
    dome.visible = settings.safetyField;
    scene.add(dome);

    const grid = new THREE.GridHelper(34, 42, '#284a40', '#192d27');
    grid.position.y = -0.29;
    const gridMaterials = Array.isArray(grid.material) ? grid.material : [grid.material];
    gridMaterials.forEach((material) => {
      material.transparent = true;
      material.opacity = 0.32;
    });
    scene.add(grid);

    const count = compact ? 330 : 510;
    const positions = new Float32Array(count * 3);
    const speeds = new Float32Array(count);
    for (let i = 0; i < count; i += 1) {
      positions[i * 3] = (Math.random() - 0.5) * 19;
      positions[i * 3 + 1] = Math.random() * 8.6 + 0.25;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 15;
      speeds[i] = 0.0025 + Math.random() * 0.012;
    }
    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMaterial = new THREE.PointsMaterial({
      color: colorRef.current,
      size: 0.075,
      transparent: true,
      opacity: 0.74,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const cloudMaterials: THREE.MeshBasicMaterial[] = [];
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    particles.visible = settings.particles;
    scene.add(particles);

    const flowGroup = new THREE.Group();
    const flowMaterials: THREE.MeshBasicMaterial[] = [];
    for (let loop = 0; loop < 3; loop += 1) {
      const radiusX = 6.8 + loop * 0.88;
      const radiusZ = 4.3 + loop * 0.68;
      const path = Array.from({ length: 57 }, (_, index) => {
        const angle = (index / 56) * Math.PI * 2;
        return new THREE.Vector3(Math.cos(angle) * radiusX, 0.72 + loop * 0.22 + Math.sin(angle * 2 + loop) * 0.4, Math.sin(angle) * radiusZ);
      });
      const flowMaterial = new THREE.MeshBasicMaterial({ color: colorRef.current, transparent: true, opacity: 0.2 - loop * 0.035, depthWrite: false, blending: THREE.AdditiveBlending });
      flowMaterials.push(flowMaterial);
      const ribbon = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(path, true, 'catmullrom', 0.35), 110, 0.024, 6, true), flowMaterial);
      flowGroup.add(ribbon);
    }
    scene.add(flowGroup);
    flowGroup.visible = settings.airflow;

    const wind = new THREE.Group();
    for (let i = 0; i < 4; i += 1) {
      const cloudMaterial = new THREE.MeshBasicMaterial({
        color: i % 2 ? '#d27662' : '#e2ac73',
        transparent: true,
        opacity: 0.044 - i * 0.004,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
      cloudMaterials.push(cloudMaterial);
      const cloud = new THREE.Mesh(
        new THREE.SphereGeometry(3.7 + i * 0.65, 20, 14),
        cloudMaterial,
      );
      cloud.position.set(3.7 + i * 0.6, 3.7 + i * 0.42, -1.7 - i * 0.5);
      cloud.scale.set(1.55, 0.48, 0.78);
      wind.add(cloud);
    }
    scene.add(wind);
    wind.visible = settings.haze;

    const auraMaterial = new THREE.MeshBasicMaterial({ color: colorRef.current, transparent: true, opacity: 0.42 });
    const aura = new THREE.Mesh(
      new THREE.TorusGeometry(2.9, 0.035, 8, 72),
      auraMaterial,
    );
    aura.rotation.x = Math.PI / 2;
    aura.position.set(0, 0.12, 0.15);
    aura.scale.set(1.42, 0.73, 1);
    scene.add(aura);
    colorTargetsRef.current = { particles: particleMaterial, aura: auraMaterial, dome: domeMaterial, haze: hazeLight, clouds: cloudMaterials, flows: flowMaterials };

    const resize = () => {
      const { width, height } = host.getBoundingClientRect();
      if (!width || !height) return;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
      if (reducedMotion) renderer.render(scene, camera);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);
    resize();

    let frame = 0;
    let disposed = false;
    let inViewport = true;
    const shouldAnimate = () => !disposed && !reducedMotion && !reduceSceneMotion && inViewport && !document.hidden;
    const renderStill = () => {
      if (!disposed && inViewport && !document.hidden) renderer.render(scene, camera);
    };
    const stopAnimation = () => {
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
    };
    const animate = () => {
      if (!shouldAnimate()) return;
      frame = window.requestAnimationFrame(animate);
      const time = performance.now() * 0.001;
      const position = particleGeometry.getAttribute('position') as THREE.BufferAttribute;
      for (let i = 0; i < count; i += 1) {
        const yIndex = i * 3 + 1;
        position.array[yIndex] += speeds[i];
        position.array[i * 3] += Math.sin(time * 0.55 + i) * 0.00095;
        if (position.array[yIndex] > 9.8) {
          position.array[yIndex] = 0.15;
          position.array[i * 3] = (Math.random() - 0.5) * 19;
        }
      }
      position.needsUpdate = true;
      particles.rotation.y = Math.sin(time * 0.09) * 0.032;
      flowGroup.rotation.y = time * 0.027;
      dome.rotation.y = -time * 0.011;
      dome.scale.setScalar(1 + Math.sin(time * 0.45) * 0.004);
      wind.position.x = Math.sin(time * 0.18) * 0.36;
      wind.position.y = Math.cos(time * 0.16) * 0.12;
      campus.position.y = Math.sin(time * 0.72) * 0.035;
      aura.material.opacity = auraOpacityRef.current + Math.sin(time * 1.5) * 0.045;
      controls.update();
      renderer.render(scene, camera);
    };
    const syncMotion = () => {
      reducedMotion = motionQuery.matches;
      controls.autoRotate = !reducedMotion && !reduceSceneMotion && settings.autoRotate;
      controls.enableDamping = !reducedMotion && !reduceSceneMotion;
      stopAnimation();
      if (shouldAnimate()) animate();
      else renderStill();
    };
    const renderOnControlChange = () => {
      if (!shouldAnimate()) renderStill();
    };
    controls.addEventListener('change', renderOnControlChange);
    motionQuery.addEventListener('change', syncMotion);
    document.addEventListener('visibilitychange', syncMotion);
    let viewportObserver: IntersectionObserver | null = null;
    if (typeof IntersectionObserver !== 'undefined') {
      viewportObserver = new IntersectionObserver((entries) => {
        inViewport = entries[0]?.isIntersecting ?? true;
        syncMotion();
      });
      viewportObserver.observe(host);
    }
    syncMotion();

    return () => {
      disposed = true;
      stopAnimation();
      observer.disconnect();
      viewportObserver?.disconnect();
      motionQuery.removeEventListener('change', syncMotion);
      document.removeEventListener('visibilitychange', syncMotion);
      controls.removeEventListener('change', renderOnControlChange);
      controls.dispose();
      colorTargetsRef.current = { particles: null, aura: null, dome: null, haze: null, clouds: [], flows: [] };
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points || object instanceof THREE.LineSegments) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [compact, reduceSceneMotion, settings]);

  useEffect(() => {
    colorRef.current.copy(airColor(aqi));
    const targets = colorTargetsRef.current;
    const severity = THREE.MathUtils.clamp((aqi - 70) / 340, 0, 1);
    targets.particles?.color.copy(colorRef.current);
    if (targets.particles) {
      targets.particles.size = 0.055 + severity * 0.055;
      targets.particles.opacity = 0.48 + severity * 0.3;
    }
    targets.aura?.color.copy(colorRef.current);
    auraOpacityRef.current = 0.25 + severity * 0.24;
    if (targets.aura) targets.aura.opacity = auraOpacityRef.current;
    targets.dome?.color.copy(colorRef.current);
    if (targets.dome) targets.dome.opacity = 0.025 + severity * 0.035;
    if (targets.haze) {
      targets.haze.color.copy(colorRef.current);
      targets.haze.intensity = 5 + severity * 13;
    }
    targets.clouds.forEach((material, index) => {
      material.color.copy(colorRef.current);
      material.opacity = 0.012 + severity * (0.034 - index * 0.005);
    });
    targets.flows.forEach((material, index) => {
      material.color.copy(colorRef.current);
      material.opacity = 0.08 + severity * (0.22 - index * 0.035);
    });
  }, [aqi]);

  return (
    <div className={`atmosphere-scene ${compact ? 'atmosphere-scene--compact' : ''}`} ref={hostRef}>
      <div className="scene-grid-overlay" />
      <div className="scene-label scene-label--top"><span className="scene-pulse" /> AQI FIELD / DELHI-NCR</div>
      <div className="scene-label scene-label--bottom"><span className="orbit-hint--desktop">DRAG TO ORBIT <span>·</span> SCROLL TO ZOOM</span><span className="orbit-hint--mobile">DRAG TO ORBIT <span>·</span> PINCH TO ZOOM</span></div>
      <div className="scene-compass"><span>N</span><i /></div>
    </div>
  );
}
