export type DecisionStatus = 'GO' | 'MODIFY' | 'NO-GO';
export type ActivityKind = 'Assembly' | 'PE' | 'Practice' | 'Competition';
export type ParticipantGroup = 'Primary (6–11)' | 'Middle / Senior' | 'Competition team';
export type Venue = 'Outdoor' | 'Indoor';
export type ViewId = 'overview' | 'planner' | 'decisions' | 'advisories' | 'settings' | 'customize';
export type DecisionDataBasis = 'demo-forecast' | 'live-current' | 'live-forecast';

export interface Activity {
  id: string;
  title: string;
  kind: ActivityKind;
  time: string;
  group: ParticipantGroup;
  venue: Venue;
  details: string;
}

export interface SchoolProfile {
  schoolName: string;
  district: string;
  station: string;
  safeMax: number;
  moderateMax: number;
  highMax: number;
  advisoryActive: boolean;
}

export type DecisionProfileSnapshot = Pick<SchoolProfile, 'schoolName' | 'district' | 'station' | 'safeMax' | 'moderateMax' | 'highMax' | 'advisoryActive'>;

export interface DecisionEvidence {
  dataBasis?: DecisionDataBasis;
  source?: string;
  sourceUrl?: string;
  observationLabel?: string;
  sourceCheckedAt?: string;
  dataCoverage?: string;
}

export interface Decision {
  id: string;
  activityId: string;
  title: string;
  kind: ActivityKind;
  time: string;
  group: ParticipantGroup;
  venue: Venue;
  status: DecisionStatus;
  action: string;
  reasons: string[];
  aqi: number;
  band: string;
  source: string;
  sourceUrl?: string;
  observationLabel?: string;
  sourceCheckedAt?: string;
  dataCoverage?: string;
  dataBasis?: DecisionDataBasis;
  profileSnapshot?: DecisionProfileSnapshot;
  recordedAt: string;
  statusChange?: string;
}

export interface AppAlert {
  id: string;
  title: string;
  detail: string;
  time: string;
  status: DecisionStatus | 'INFO';
  read: boolean;
}

export interface ForecastPoint {
  time: string;
  aqi: number;
  label: string;
}

export interface LiveAqiReading {
  city: string;
  aqi: number;
  category: string;
  pollutant: string;
  reportingStations: number;
  totalStations: number;
  coverage: string;
  observationLabel: string;
  observedAt: string | null;
  freshness: 'fresh' | 'stale';
  sourceName: string;
  sourceUrl: string;
  evidence: string;
  fetchedAt: string;
}

export interface LiveSourceStatus {
  id: string;
  name: string;
  status: 'verified' | 'active' | 'order-found' | 'found' | 'stale' | 'unavailable';
  title: string;
  url: string | null;
  checkedAt: string;
  note: string;
}

export interface LiveForecastStatus {
  status: 'unavailable' | 'available';
  sourceUrl: string | null;
  checkedAt: string;
  message: string;
  points: ForecastPoint[];
}

export interface LiveAdvisoryStatus {
  status: 'active' | 'order-found' | 'unavailable';
  stage: string | null;
  title: string;
  effectiveDate: string | null;
  sourceUrl: string | null;
  orderPdfUrl: string | null;
  scheduleUrl?: string | null;
  scheduleExcerpt?: string | null;
  evidence: string;
  checkedAt: string;
  interpretation: string;
}

export interface TinyFishSnapshot {
  provider: 'TinyFish Search + Fetch';
  city: string;
  fetchedAt: string;
  mode: 'live' | 'partial';
  currentAqi: LiveAqiReading | null;
  forecast: LiveForecastStatus;
  advisory: LiveAdvisoryStatus;
  sources: LiveSourceStatus[];
  warnings: string[];
  searchSummary: {
    cpcbResults: number;
    forecastResults: number;
    caqmResults: number;
    fetchSucceeded: number;
    fetchFailed: number;
  };
  cache?: { hit: boolean; ageSeconds: number; coalesced?: boolean };
}
