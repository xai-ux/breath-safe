import type { ViewId } from './types';

export type ThemeMode = 'canopy' | 'midnight' | 'contrast';
export type DensityMode = 'comfortable' | 'compact';
export type FontMode = 'dm-sans' | 'system' | 'atkinson';
export type ClockFormat = '12h' | '24h';
export type StartPage = Exclude<ViewId, 'customize'>;

export interface ScenePreferences {
  particles: boolean;
  haze: boolean;
  airflow: boolean;
  safetyField: boolean;
  autoRotate: boolean;
}

export interface DashboardPreferences {
  scene: boolean;
  trend: boolean;
  activities: boolean;
  advisory: boolean;
  alerts: boolean;
}

export interface PlatformPreferences {
  theme: ThemeMode;
  accentColor: string;
  density: DensityMode;
  font: FontMode;
  textScale: 90 | 100 | 110 | 120;
  highContrast: boolean;
  reducedMotion: boolean;
  clockFormat: ClockFormat;
  startPage: StartPage;
  autoSyncOnLaunch: boolean;
  scene: ScenePreferences;
  dashboard: DashboardPreferences;
}

export const PREFERENCES_KEY = 'breathesafe-platform-preferences-v1';

export const ACCENT_PRESETS = [
  { name: 'Airflow mint', value: '#68d9ae' },
  { name: 'Clear sky', value: '#54b9dd' },
  { name: 'Iris', value: '#a78bfa' },
  { name: 'Amber', value: '#efb35e' },
  { name: 'Rose', value: '#ed8e9c' },
  { name: 'Coral', value: '#e77d63' },
] as const;

export const DEFAULT_PREFERENCES: PlatformPreferences = {
  theme: 'canopy',
  accentColor: '#68d9ae',
  density: 'comfortable',
  font: 'dm-sans',
  textScale: 100,
  highContrast: false,
  reducedMotion: false,
  clockFormat: '12h',
  startPage: 'overview',
  autoSyncOnLaunch: false,
  scene: { particles: true, haze: true, airflow: true, safetyField: true, autoRotate: true },
  dashboard: { scene: true, trend: true, activities: true, advisory: true, alerts: true },
};

const startPages: StartPage[] = ['overview', 'planner', 'decisions', 'advisories', 'settings'];
const scales = [90, 100, 110, 120] as const;
const isBoolean = (value: unknown): value is boolean => typeof value === 'boolean';

export function loadPlatformPreferences(): PlatformPreferences {
  if (typeof window === 'undefined') return DEFAULT_PREFERENCES;
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(PREFERENCES_KEY) ?? 'null');
    if (!parsed || typeof parsed !== 'object') return DEFAULT_PREFERENCES;
    const value = parsed as Partial<PlatformPreferences>;
    const validColor = typeof value.accentColor === 'string' && /^#[0-9a-f]{6}$/i.test(value.accentColor);
    const scene: Partial<ScenePreferences> = value.scene && typeof value.scene === 'object' ? value.scene : {};
    const dashboard: Partial<DashboardPreferences> = value.dashboard && typeof value.dashboard === 'object' ? value.dashboard : {};
    return {
      theme: value.theme === 'midnight' || value.theme === 'contrast' ? value.theme : 'canopy',
      accentColor: validColor ? value.accentColor! : DEFAULT_PREFERENCES.accentColor,
      density: value.density === 'compact' ? 'compact' : 'comfortable',
      font: value.font === 'system' || value.font === 'atkinson' ? value.font : 'dm-sans',
      textScale: scales.includes(value.textScale as (typeof scales)[number]) ? value.textScale as PlatformPreferences['textScale'] : 100,
      highContrast: isBoolean(value.highContrast) ? value.highContrast : false,
      reducedMotion: isBoolean(value.reducedMotion) ? value.reducedMotion : false,
      clockFormat: value.clockFormat === '24h' ? '24h' : '12h',
      startPage: startPages.includes(value.startPage as StartPage) ? value.startPage as StartPage : 'overview',
      autoSyncOnLaunch: isBoolean(value.autoSyncOnLaunch) ? value.autoSyncOnLaunch : false,
      scene: {
        particles: isBoolean(scene.particles) ? scene.particles : true,
        haze: isBoolean(scene.haze) ? scene.haze : true,
        airflow: isBoolean(scene.airflow) ? scene.airflow : true,
        safetyField: isBoolean(scene.safetyField) ? scene.safetyField : true,
        autoRotate: isBoolean(scene.autoRotate) ? scene.autoRotate : true,
      },
      dashboard: {
        scene: isBoolean(dashboard.scene) ? dashboard.scene : true,
        trend: isBoolean(dashboard.trend) ? dashboard.trend : true,
        activities: isBoolean(dashboard.activities) ? dashboard.activities : true,
        advisory: isBoolean(dashboard.advisory) ? dashboard.advisory : true,
        alerts: isBoolean(dashboard.alerts) ? dashboard.alerts : true,
      },
    };
  } catch {
    return DEFAULT_PREFERENCES;
  }
}
