import assert from 'node:assert/strict';
import test from 'node:test';
import { parseCaqmStatus, parseCpcbBulletin, resolveNcrCity } from './tinyfish.mjs';

const cpcbText = `Air Quality Index on Oct 24, 2026 @ 4 PM\n(Average of past 24 hours)\nS.No City Air Quality Index Value Prominent Pollutant\n80 Delhi Moderate 191 PM2.5, PM10 57/59\n81 Dewas Moderate 112 NO2 1/1`;

test('maps the Delhi-NCR profile label to the CPCB Delhi city row', () => {
  assert.equal(resolveNcrCity('Delhi-NCR reference grid'), 'Delhi');
  const reading = parseCpcbBulletin(cpcbText, 'Delhi-NCR');
  assert.ok(reading);
  assert.equal(reading.city, 'Delhi');
  assert.equal(reading.aqi, 191);
  assert.equal(reading.category, 'Moderate');
  assert.equal(reading.reportingStations, 57);
  assert.equal(reading.totalStations, 59);
  assert.match(reading.observationLabel, /Oct 24, 2026 @ 4 PM · past 24-hour average/);
  assert.equal(reading.freshness, 'fresh');
});

test('parses a multi-word NCR city and does not borrow the neighboring row AQI', () => {
  const text = 'Air Quality Index on Oct 24, 2026 @ 4 PM (Average of past 24 hours) 101 Greater Noida Moderate 169 PM10 2/2 102 Gurugram Moderate 174 PM2.5 4/4';
  const reading = parseCpcbBulletin(text, 'Greater Noida');
  assert.equal(reading?.aqi, 169);
  assert.equal(reading?.city, 'Greater Noida');
  assert.equal(parseCpcbBulletin(text, 'Faridabad'), null);
});

test('rejects unsupported locations rather than returning a neighboring city', () => {
  assert.equal(resolveNcrCity('Mumbai'), null);
  assert.equal(parseCpcbBulletin(cpcbText, 'Mumbai'), null);
});

test('requires explicit active-and-in-force wording before declaring a GRAP stage active', () => {
  const active = parseCaqmStatus([
    { title: 'CAQM: Home', snippet: 'Stage-I Active & In Force Effective: 21 Oct 2026', url: 'https://caqm.nic.in/' },
  ]);
  assert.equal(active.status, 'active');
  assert.equal(active.stage, 'Stage I');
  assert.equal(active.effectiveDate, '21 Oct 2026');

  const invocationOnly = parseCaqmStatus([
    { title: 'GRAP Orders', snippet: 'Implementation of actions under Stage-I, dated 21.10.2026', url: 'https://caqm.nic.in/landingpage/pages/grap/grap-orders' },
  ]);
  assert.equal(invocationOnly.status, 'order-found');
  assert.notEqual(invocationOnly.status, 'active');
});
