const SEARCH_ENDPOINT = 'https://api.search.tinyfish.ai';
const FETCH_ENDPOINT = 'https://api.fetch.tinyfish.ai';
const CPCB_BULLETIN_URL = 'https://cpcb.gov.in/aqi_report.php';
const SAFAR_FORECAST_URL = 'https://safar.tropmet.res.in/pdf/delhi.pdf';
const ALLOWED_HOSTS = [
  'cpcb.gov.in',
  'cpcb.nic.in',
  'airquality.cpcb.gov.in',
  'data.gov.in',
  'caqm.nic.in',
  'safar.tropmet.res.in',
  'mausam.imd.gov.in',
];
const CITY_ALIASES = new Map([
  ['delhi', 'Delhi'],
  ['new delhi', 'Delhi'],
  ['delhi ncr', 'Delhi'],
  ['delhi ncr reference grid', 'Delhi'],
  ['ncr', 'Delhi'],
  ['national capital region', 'Delhi'],
  ['noida', 'Noida'],
  ['greater noida', 'Greater Noida'],
  ['gautam buddha nagar', 'Greater Noida'],
  ['ghaziabad', 'Ghaziabad'],
  ['faridabad', 'Faridabad'],
  ['gurugram', 'Gurugram'],
  ['gurgaon', 'Gurugram'],
  ['bahadurgarh', 'Bahadurgarh'],
  ['bhiwadi', 'Bhiwadi'],
  ['sonipat', 'Sonipat'],
  ['sonepat', 'Sonipat'],
  ['palwal', 'Palwal'],
  ['panipat', 'Panipat'],
  ['alwar', 'Alwar'],
  ['meerut', 'Meerut'],
  ['rohtak', 'Rohtak'],
  ['jhajjar', 'Jhajjar'],
  ['rewari', 'Rewari'],
]);

function normalizeLocation(value) {
  return String(value ?? 'Delhi-NCR').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

export function resolveNcrCity(value = 'Delhi-NCR') {
  return CITY_ALIASES.get(normalizeLocation(value)) ?? null;
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function parseIndianObservation(label) {
  if (!label) return null;
  const match = label.match(/([A-Za-z]{3,})\s+(\d{1,2}),\s*(\d{4})\s*@\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM)/i);
  if (!match) return null;
  const month = new Date(`${match[1]} 1, 2000 UTC`).getUTCMonth();
  if (!Number.isFinite(month)) return null;
  let hour = Number(match[4]) % 12;
  if (match[6].toUpperCase() === 'PM') hour += 12;
  const utcMillis = Date.UTC(Number(match[3]), month, Number(match[2]), hour, Number(match[5] ?? 0)) - (5.5 * 60 * 60 * 1000);
  return new Date(utcMillis).toISOString();
}

export function parseCpcbBulletin(text, requestedCity = 'Delhi') {
  if (typeof text !== 'string' || !text.trim()) return null;
  const header = text.match(/Air\s+Quality\s+Index\s+on\s+([^\r\n]{6,100})/i)?.[1]?.trim() ?? '';
  const dateLabel = header.match(/[A-Za-z]{3,}\s+\d{1,2},\s*\d{4}\s*@\s*\d{1,2}(?::\d{2})?\s*(?:AM|PM)/i)?.[0] ?? null;
  const observedAt = parseIndianObservation(dateLabel);
  const flat = text.replace(/\s+/g, ' ').trim();
  const city = resolveNcrCity(requestedCity) ?? requestedCity;
  const category = '(Good|Satisfactory|Moderate|Poor|Very\\s+Poor|Severe)';
  const pattern = new RegExp(`(?:^|\\s)\\d+\\s+${escapeRegExp(city)}\\s+${category}\\s+(\\d{1,3})\\s+(.{1,100}?)\\s+(\\d{1,3})\\s*\\/\\s*(\\d{1,3})(?=\\s|$)`, 'i');
  const row = flat.match(pattern);
  if (!row) return null;
  const aqi = Number(row[2]);
  const reportingStations = Number(row[4]);
  const totalStations = Number(row[5]);
  if (!Number.isInteger(aqi) || aqi < 0 || aqi > 500 || totalStations < 1 || reportingStations > totalStations) return null;
  const ageMs = observedAt ? Date.now() - new Date(observedAt).getTime() : Number.POSITIVE_INFINITY;
  const fresh = ageMs >= -3 * 60 * 60 * 1000 && ageMs <= 30 * 60 * 60 * 1000;
  const evidence = `${row[1]} ${aqi} ${row[3].trim().replace(/\s+/g, ' ')} ${reportingStations}/${totalStations}`;
  return {
    city,
    aqi,
    category: row[1].replace(/\s+/g, ' '),
    pollutant: row[3].trim().replace(/\s+/g, ' '),
    reportingStations,
    totalStations,
    coverage: `${reportingStations}/${totalStations} stations reporting`,
    observationLabel: dateLabel ? `${dateLabel}${/average of past 24 hours/i.test(text) ? ' · past 24-hour average' : ''}` : 'Observation time not extracted from bulletin',
    observedAt,
    freshness: fresh ? 'fresh' : 'stale',
    sourceName: 'CPCB National AQI Bulletin',
    evidence,
  };
}

function safeOfficialUrl(raw) {
  try {
    const url = new URL(raw);
    if (url.protocol !== 'https:' || url.username || url.password) return null;
    const hostAllowed = ALLOWED_HOSTS.some((host) => url.hostname === host || url.hostname.endsWith(`.${host}`));
    if (!hostAllowed) return null;
    url.hash = '';
    url.pathname = url.pathname.replace(/\/{2,}/g, '/');
    for (const key of [...url.searchParams.keys()]) {
      if (/^(utm_|fbclid$|gclid$)/i.test(key)) url.searchParams.delete(key);
    }
    return url.toString();
  } catch {
    return null;
  }
}

function tinyfishErrorCode(body, status) {
  const code = body && typeof body === 'object' ? body.error?.code ?? body.error : null;
  return typeof code === 'string' && /^[a-zA-Z0-9_-]{1,80}$/.test(code) ? code : `HTTP_${status}`;
}

async function searchTinyfish(query, domains, key) {
  const url = new URL(SEARCH_ENDPOINT);
  url.searchParams.set('query', query);
  url.searchParams.set('location', 'IN');
  url.searchParams.set('language', 'en');
  url.searchParams.set('include_domains', domains);
  url.searchParams.set('purpose', 'Find official government air-quality and Delhi-NCR GRAP evidence for a school-safety dashboard.');
  try {
    const response = await fetch(url, { headers: { 'X-API-Key': key }, signal: AbortSignal.timeout(12_000) });
    const body = await response.json().catch(() => null);
    if (!response.ok) return { ok: false, results: [], error: tinyfishErrorCode(body, response.status) };
    return { ok: true, results: Array.isArray(body?.results) ? body.results : [], error: null };
  } catch (error) {
    return { ok: false, results: [], error: error?.name === 'TimeoutError' ? 'timeout' : 'network_error' };
  }
}

async function fetchTinyfish(urls, key) {
  const safeUrls = [...new Set(urls.map(safeOfficialUrl).filter(Boolean))].slice(0, 10);
  if (!safeUrls.length) return { results: [], errors: [], error: null };
  try {
    const response = await fetch(FETCH_ENDPOINT, {
      method: 'POST',
      headers: { 'X-API-Key': key, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        urls: safeUrls,
        format: 'markdown',
        ttl: 0,
        per_url_timeout_ms: 60_000,
        purpose: 'Extract current CPCB AQI and official CAQM GRAP order evidence; preserve dates and source context.',
      }),
      signal: AbortSignal.timeout(122_000),
    });
    const body = await response.json().catch(() => null);
    if (!response.ok) return { results: [], errors: [], error: tinyfishErrorCode(body, response.status) };
    return {
      results: Array.isArray(body?.results) ? body.results : [],
      errors: Array.isArray(body?.errors) ? body.errors : [],
      error: null,
    };
  } catch (error) {
    return { results: [], errors: [], error: error?.name === 'TimeoutError' ? 'timeout' : 'network_error' };
  }
}

function isCaqmOrderPdf(value) {
  const safe = safeOfficialUrl(value);
  if (!safe) return false;
  const url = new URL(safe);
  return url.hostname === 'caqm.nic.in' && /\/FileUploadDomain\/WebsiteDocument\/GRAP\/GRAP(?:%20|\s)Orders\//i.test(url.pathname) && /\.pdf$/i.test(url.pathname);
}

function isCaqmSchedulePdf(value) {
  const safe = safeOfficialUrl(value);
  if (!safe) return false;
  const url = new URL(safe);
  return url.hostname === 'caqm.nic.in' && /\/FileUploadDomain\/WebsiteDocument\/GRAP\/GRAP(?:%20|\s)Schedule\//i.test(url.pathname) && /\.pdf$/i.test(url.pathname);
}

function firstOfficialResult(results, predicate) {
  return results.find((item) => safeOfficialUrl(item?.url) && predicate(item)) ?? null;
}

function parseStage(text) {
  const match = String(text).match(/stage\s*[-–:]?\s*(IV|III|II|I)\b/i);
  return match ? `Stage ${match[1].toUpperCase()}` : null;
}

function parseOrderDate(text) {
  const value = String(text);
  const numeric = value.match(/\b(\d{1,2})[./-](\d{1,2})[./-](\d{4})\b/);
  if (numeric) {
    const [, day, month, year] = numeric;
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${Number(day)} ${months[Number(month) - 1] ?? month} ${year}`;
  }
  const wordDate = value.match(/\b(\d{1,2})(?:st|nd|rd|th)?[ ,.-]+(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[ ,.-]+(\d{4})\b/i);
  if (!wordDate) return null;
  return `${Number(wordDate[1])} ${wordDate[2].slice(0, 3)} ${wordDate[3]}`;
}

export function parseCaqmStatus(searchResults = [], orderText = '', checkedAt = new Date().toISOString()) {
  const all = searchResults.filter((item) => safeOfficialUrl(item?.url));
  const activeListing = all.find((item) => /active\s*(?:&|and)\s*in\s*force/i.test(`${item.title ?? ''} ${item.snippet ?? ''}`) && /stage\s*[-–:]?\s*(?:IV|III|II|I)\b/i.test(`${item.title ?? ''} ${item.snippet ?? ''}`));
  const orderListing = all.find((item) => /invocation|implementation of actions under|dated\s*\d/i.test(`${item.title ?? ''} ${item.snippet ?? ''}`) && /stage\s*[-–:]?\s*(?:IV|III|II|I)\b/i.test(`${item.title ?? ''} ${item.snippet ?? ''}`));
  const primary = activeListing ?? orderListing ?? all.find((item) => /caqm\.nic\.in/i.test(item.url)) ?? null;
  const combined = `${primary?.title ?? ''} ${primary?.snippet ?? ''} ${orderText}`;
  const stage = parseStage(combined);
  const active = Boolean(activeListing);
  const date = parseOrderDate(`${activeListing?.snippet ?? ''} ${orderListing?.snippet ?? ''} ${orderText}`);
  const snippet = String(activeListing?.snippet ?? orderListing?.snippet ?? '').trim().slice(0, 700);
  const heading = orderText.match(/(?:ORDER\s*Sub\.?\s*:\s*)([^\n]{10,240})/i)?.[1]?.trim() ?? null;
  return {
    status: active ? 'active' : orderListing || orderText ? 'order-found' : 'unavailable',
    stage,
    title: heading || (stage ? `CAQM ${stage} order for Delhi-NCR` : 'CAQM GRAP status not verified'),
    effectiveDate: date,
    sourceUrl: safeOfficialUrl(primary?.url) ?? 'https://caqm.nic.in/',
    orderPdfUrl: all.find((item) => isCaqmOrderPdf(item.url)) ? safeOfficialUrl(all.find((item) => isCaqmOrderPdf(item.url)).url) : null,
    evidence: snippet || orderText.replace(/\s+/g, ' ').trim().slice(0, 700),
    checkedAt,
    interpretation: active
      ? 'CAQM search result marks this stage active/in force. The general NCR stage is context; it does not by itself cancel every school activity.'
      : 'A recent official order was found, but current in-force status was not confirmed by the extracted listing. Verify the source before applying a school restriction.',
  };
}

function observationFromText(text) {
  const value = String(text ?? '').replace(/\s+/g, ' ');
  return value.match(/Air\s+Quality\s+Index\s+on\s+([^\n]{0,160}?)(?:\s+\(Average of past 24 hours\)|\s+S\.No\s+City|$)/i)?.[1]?.trim() ?? '';
}

function dateLabelFromBulletin(text) {
  const direct = String(text ?? '').match(/Air\s+Quality\s+Index\s+on\s+([A-Za-z]{3,}\s+\d{1,2},\s*\d{4}\s*@\s*\d{1,2}(?::\d{2})?\s*(?:AM|PM))/i);
  return direct?.[1]?.trim() ?? observationFromText(text);
}

export async function refreshTinyFishSources({ location = 'Delhi-NCR' } = {}) {
  const key = process.env.TINYFISH_API_KEY;
  if (!key) {
    const error = new Error('TinyFish is not configured for this server environment.');
    error.code = 'tinyfish_not_configured';
    throw error;
  }
  const city = resolveNcrCity(location);
  if (!city) {
    const error = new Error('Choose a Delhi-NCR city supported by the CPCB bulletin.');
    error.code = 'unsupported_city';
    throw error;
  }

  const now = new Date();
  const checkedAt = now.toISOString();
  const monthYear = new Intl.DateTimeFormat('en-IN', { month: 'long', year: 'numeric', timeZone: 'Asia/Kolkata' }).format(now);
  const [aqiSearch, forecastSearch, caqmStatusSearch, caqmOrderSearch] = await Promise.all([
    searchTinyfish(`CPCB National AQI bulletin ${city} current city reading`, 'cpcb.gov.in,cpcb.nic.in,airquality.cpcb.gov.in,data.gov.in', key),
    searchTinyfish(`SAFAR ${city} Delhi NCR air quality AQI forecast next 24 hours official ${monthYear}`, 'safar.tropmet.res.in,mausam.imd.gov.in,moes.gov.in', key),
    searchTinyfish(`CAQM current active GRAP stage in force Delhi NCR ${monthYear}`, 'caqm.nic.in', key),
    searchTinyfish(`CAQM latest GRAP order invocation Delhi NCR ${monthYear} official PDF`, 'caqm.nic.in', key),
  ]);

  const searchRows = [...caqmStatusSearch.results, ...caqmOrderSearch.results];
  const caqmOrderResult = firstOfficialResult(searchRows, (item) => isCaqmOrderPdf(item.url) && /order|stage|invocation|implementation/i.test(`${item.title ?? ''} ${item.snippet ?? ''}`));
  const caqmScheduleResult = firstOfficialResult(searchRows, (item) => isCaqmSchedulePdf(item.url));
  const safarResult = firstOfficialResult(forecastSearch.results, (item) => /safar/i.test(`${item.site_name ?? ''} ${item.title ?? ''}`) && /forecast|delhi/i.test(`${item.title ?? ''} ${item.snippet ?? ''}`));
  const safarPdfResult = firstOfficialResult(forecastSearch.results, (item) => /safar\.tropmet\.res\.in/i.test(item.url) && /\.pdf(?:$|\?)/i.test(item.url) && /delhi/i.test(item.url));
  const safarUrl = safeOfficialUrl(safarPdfResult?.url ?? SAFAR_FORECAST_URL);
  const caqmOrderUrl = safeOfficialUrl(caqmOrderResult?.url);
  const caqmScheduleUrl = safeOfficialUrl(caqmScheduleResult?.url);

  const requestedFetches = [
    { id: 'cpcb', url: CPCB_BULLETIN_URL },
    ...(caqmOrderUrl ? [{ id: 'caqm-order', url: caqmOrderUrl }] : []),
    ...(caqmScheduleUrl ? [{ id: 'caqm-schedule', url: caqmScheduleUrl }] : []),
    ...(safarUrl ? [{ id: 'safar-forecast', url: safarUrl }] : []),
  ];
  const fetchResult = await fetchTinyfish(requestedFetches.map((item) => item.url), key);
  const fetchedAt = new Date().toISOString();
  const fetchedByUrl = new Map(fetchResult.results.map((item) => [safeOfficialUrl(item.url), item]));
  const errorsByUrl = new Map(fetchResult.errors.map((item) => [safeOfficialUrl(item.url), item.error]));
  const fetchedById = new Map(requestedFetches.map((request) => [request.id, fetchedByUrl.get(safeOfficialUrl(request.url)) ?? null]));
  const errorsById = new Map(requestedFetches.map((request) => [request.id, errorsByUrl.get(safeOfficialUrl(request.url)) ?? fetchResult.error ?? null]));

  const cpcbDocument = fetchedById.get('cpcb');
  const cpcbReading = parseCpcbBulletin(cpcbDocument?.text, city);
  const currentAqi = cpcbReading ? {
    ...cpcbReading,
    sourceUrl: safeOfficialUrl(cpcbDocument.final_url) ?? CPCB_BULLETIN_URL,
    fetchedAt,
  } : null;
  const caqmDocument = fetchedById.get('caqm-order');
  const scheduleDocument = fetchedById.get('caqm-schedule');
  const caqm = parseCaqmStatus(searchRows, caqmDocument?.text ?? '', fetchedAt);
  if (caqmOrderUrl && !caqm.orderPdfUrl) caqm.orderPdfUrl = caqmOrderUrl;
  if (caqmScheduleUrl) caqm.scheduleUrl = caqmScheduleUrl;
  if (scheduleDocument?.text) {
    const stageIndex = scheduleDocument.text.search(/Stage\s*[–-]?\s*I\b/i);
    caqm.scheduleExcerpt = stageIndex >= 0 ? scheduleDocument.text.slice(stageIndex, stageIndex + 850).replace(/\s+/g, ' ').trim() : null;
  }
  if (!caqm.orderPdfUrl && caqmDocument?.final_url) caqm.orderPdfUrl = safeOfficialUrl(caqmDocument.final_url);

  const safarDocument = fetchedById.get('safar-forecast');
  const safarError = errorsById.get('safar-forecast');
  const forecast = {
    status: 'unavailable',
    sourceUrl: safeOfficialUrl(safarDocument?.final_url) ?? safarUrl,
    checkedAt: fetchedAt,
    message: safarError
      ? `TinyFish Fetch could not retrieve the official SAFAR forecast (${safarError}); no forward projection is used in live decisions. SAFAR numeric forecast parsing is not implemented yet.`
      : 'A SAFAR source was found, but numeric forecast parsing is not implemented yet; no forward projection is used in live decisions.',
    points: [],
  };

  const cpcbSearchSource = firstOfficialResult(aqiSearch.results, (item) => /cpcb|data\.gov\.in/i.test(`${item.site_name ?? ''} ${item.url}`));
  const sources = [
    {
      id: 'cpcb', name: 'CPCB National AQI Bulletin', status: currentAqi?.freshness === 'fresh' ? 'verified' : currentAqi ? 'stale' : 'unavailable',
      title: cpcbDocument?.title ?? cpcbSearchSource?.title ?? 'Current AQI bulletin',
      url: currentAqi?.sourceUrl ?? CPCB_BULLETIN_URL, checkedAt: fetchedAt,
      note: currentAqi ? `${city} · ${currentAqi.coverage} · ${currentAqi.observationLabel}` : `No source-backed ${city} reading could be parsed; search snippets are not used as AQI values.`,
    },
    {
      id: 'forecast', name: 'SAFAR AQI forecast', status: 'unavailable',
      title: safarPdfResult?.title ?? safarResult?.title ?? 'Delhi air-quality forecast',
      url: forecast.sourceUrl, checkedAt: fetchedAt, note: forecast.message,
    },
    {
      id: 'caqm', name: 'CAQM / GRAP official order', status: caqm.status,
      title: caqm.title, url: caqm.orderPdfUrl ?? caqm.sourceUrl, checkedAt: fetchedAt,
      note: caqm.status === 'active' ? `${caqm.stage ?? 'GRAP stage'} · active per current CAQM search listing${caqm.effectiveDate ? ` · effective ${caqm.effectiveDate}` : ''}` : caqm.interpretation,
    },
  ];
  if (caqm.scheduleUrl) {
    sources.push({ id: 'caqm-schedule', name: 'CAQM revised GRAP schedule', status: scheduleDocument?.text ? 'verified' : 'found', title: 'Revised schedule', url: caqm.scheduleUrl, checkedAt: fetchedAt, note: 'Official stage schedule; linked for review and not automatically converted into a school closure rule.' });
  }

  const warnings = [];
  if (aqiSearch.error) warnings.push(`CPCB source discovery returned ${aqiSearch.error}.`);
  if (forecastSearch.error) warnings.push(`SAFAR forecast search returned ${forecastSearch.error}.`);
  if (!currentAqi) warnings.push('No current AQI value passed official CPCB row and timestamp parsing; the dashboard must remain in demo mode.');
  if (currentAqi?.freshness === 'stale') warnings.push('The CPCB bulletin is older than 30 hours; it is visible as stale evidence but must not drive live decisions.');
  if (caqm.status !== 'active') warnings.push(caqm.status === 'order-found' ? 'A CAQM order was found, but current active status was not verified.' : 'The current CAQM GRAP stage was not verified from an official listing.');
  if (caqm.status === 'active' && !caqmDocument?.text) warnings.push('The official CAQM search listing reports an active stage, but the linked order text was not independently fetched. Read the official order before treating it as actionable.');
  if (fetchResult.error) warnings.push(`TinyFish Fetch returned ${fetchResult.error}.`);

  return {
    provider: 'TinyFish Search + Fetch',
    city,
    fetchedAt,
    mode: currentAqi?.freshness === 'fresh' ? 'live' : 'partial',
    currentAqi,
    forecast,
    advisory: caqm,
    sources,
    warnings,
    searchSummary: {
      cpcbResults: aqiSearch.results.length,
      forecastResults: forecastSearch.results.length,
      caqmResults: searchRows.length,
      fetchSucceeded: fetchResult.results.length,
      fetchFailed: fetchResult.errors.length,
    },
  };
}
