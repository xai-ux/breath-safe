import { createServer as createHttpServer } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { refreshTinyFishSources, resolveNcrCity } from './tinyfish.mjs';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const port = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === 'production';
const app = express();
const snapshots = new Map();
const inFlight = new Map();
const lastRequestByClient = new Map();
const snapshotTtlMs = 90_000;
const minimumRequestIntervalMs = 12_000;

app.disable('x-powered-by');
app.use(express.json({ limit: '12kb', strict: true }));
app.use((request, response, next) => {
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (request.path.startsWith('/api/')) response.setHeader('Cache-Control', 'no-store');
  next();
});

app.get('/healthz', (_request, response) => response.status(200).json({ ok: true }));
app.get('/api/tinyfish/status', (request, response) => {
  const requestedCity = typeof request.query.location === 'string' ? resolveNcrCity(request.query.location) : null;
  const entry = requestedCity
    ? snapshots.get(requestedCity)
    : [...snapshots.values()].sort((a, b) => b.storedAt - a.storedAt)[0];
  const snapshot = entry?.snapshot ?? null;
  return response.status(200).json({
    provider: 'TinyFish Search + Fetch',
    configured: Boolean(process.env.TINYFISH_API_KEY),
    feeds: ['CPCB AQI bulletin', 'CAQM / GRAP order', 'SAFAR forecast'],
    inProgress: [...inFlight.keys()],
    cache: entry ? { hit: true, ageSeconds: Math.floor((Date.now() - entry.storedAt) / 1000) } : null,
    snapshot,
  });
});

app.post('/api/tinyfish/refresh', async (request, response) => {
  if (request.get('sec-fetch-site') === 'cross-site') {
    return response.status(403).json({ error: 'Cross-site live-source requests are not accepted.' });
  }
  if (!request.is('application/json') || !request.body || typeof request.body !== 'object' || Array.isArray(request.body) || typeof request.body.location !== 'string') {
    return response.status(415).json({ error: 'Submit a JSON body with a supported Delhi-NCR location.' });
  }
  const location = request.body.location.slice(0, 120);
  const city = resolveNcrCity(location);
  if (!city) {
    return response.status(400).json({
      error: 'Choose a supported Delhi-NCR city or set the area to Delhi-NCR.',
      supportedCities: ['Delhi', 'Noida', 'Greater Noida', 'Ghaziabad', 'Faridabad', 'Gurugram', 'Bahadurgarh', 'Bhiwadi', 'Sonipat', 'Palwal', 'Panipat', 'Alwar', 'Meerut', 'Rohtak', 'Jhajjar', 'Rewari'],
    });
  }
  if (!process.env.TINYFISH_API_KEY) {
    return response.status(503).json({ error: 'TinyFish is not configured in this server environment.' });
  }

  const cacheEntry = snapshots.get(city);
  const now = Date.now();
  if (cacheEntry && now - cacheEntry.storedAt < snapshotTtlMs) {
    return response.status(200).json({ ...cacheEntry.snapshot, cache: { hit: true, ageSeconds: Math.floor((now - cacheEntry.storedAt) / 1000) } });
  }
  if (inFlight.has(city)) {
    const shared = await inFlight.get(city);
    return response.status(200).json({ ...shared, cache: { hit: true, ageSeconds: 0, coalesced: true } });
  }

  const client = request.socket.remoteAddress || 'unknown';
  const lastRequest = lastRequestByClient.get(client) ?? 0;
  if (now - lastRequest < minimumRequestIntervalMs) {
    return response.status(429).json({ error: 'Please wait a few seconds before starting another live source refresh.' });
  }
  lastRequestByClient.set(client, now);
  if (lastRequestByClient.size > 256) {
    for (const [key, timestamp] of lastRequestByClient) if (now - timestamp > 10 * 60_000) lastRequestByClient.delete(key);
  }

  const work = refreshTinyFishSources({ location: city });
  inFlight.set(city, work);
  try {
    const snapshot = await work;
    snapshots.set(city, { snapshot, storedAt: Date.now() });
    return response.status(200).json({ ...snapshot, cache: { hit: false, ageSeconds: 0 } });
  } catch (error) {
    const status = error?.code === 'unsupported_city' ? 400 : error?.code === 'tinyfish_not_configured' ? 503 : 502;
    const message = error?.code === 'unsupported_city' || error?.code === 'tinyfish_not_configured'
      ? error.message
      : 'TinyFish could not complete this refresh. The demo scenario has not been replaced.';
    return response.status(status).json({ error: message, code: error?.code ?? 'tinyfish_refresh_failed' });
  } finally {
    inFlight.delete(city);
  }
});

app.use((error, _request, response, next) => {
  if (response.headersSent) return next(error);
  if (error?.type === 'entity.too.large') return response.status(413).json({ error: 'Request body is too large.' });
  return response.status(500).json({ error: 'Unexpected application error.' });
});

const httpServer = createHttpServer(app);

if (production) {
  const dist = path.join(projectRoot, 'dist');
  app.use(express.static(dist, {
    index: false,
    fallthrough: true,
    setHeaders(response, filePath) {
      if (filePath.includes(`${path.sep}assets${path.sep}`)) response.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      else response.setHeader('Cache-Control', 'no-cache');
    },
  }));
  app.use((request, response, next) => {
    if (request.method !== 'GET' || request.path.startsWith('/api/') || path.extname(request.path)) return next();
    return response.sendFile(path.join(dist, 'index.html'), (error) => { if (error) next(error); });
  });
  app.use((_request, response) => response.status(404).json({ error: 'Not found.' }));
  httpServer.listen(port, '0.0.0.0', () => console.log(`BreatheSafe production server listening on ${port}`));
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    configFile: path.join(projectRoot, 'vite.config.ts'),
    root: projectRoot,
    appType: 'spa',
    server: { middlewareMode: true, hmr: { server: httpServer } },
  });
  app.use(vite.middlewares);
  httpServer.on('close', () => { void vite.close(); });
  httpServer.listen(port, '0.0.0.0', () => console.log(`BreatheSafe development server listening on ${port}`));
}
